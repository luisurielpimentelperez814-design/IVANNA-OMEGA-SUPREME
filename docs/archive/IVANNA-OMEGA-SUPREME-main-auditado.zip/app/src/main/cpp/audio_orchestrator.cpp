#include <jni.h>
/*
 * IVANNA-OMEGA-SUPREME v1.6 — audio_orchestrator.cpp
 * Endurecimiento de producción:
 *  - Cableado real de controles width / exciter / presence
 *  - Métricas LUFS/peak bloque a bloque
 *  - Validación de tamaños JNI
 *  - Bypass coherente en rutas estéreo y multicanal
 *  - Sanitización NaN/Inf y limitador final
 */

#include <aaudio/AAudio.h>
#include <android/log.h>
#include <cmath>
#include <atomic>
#include <mutex>
#include <thread>
#include <algorithm>
#include "anti_dolby.h"

#define LOG_TAG "IVANNA-Audio"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static constexpr float TWO_PI = 6.283185307179586f;
static constexpr float INV_TWO_PI = 0.159154943091895f;
static constexpr float LIMITER_THRESH = 0.98855f;   // -0.1 dBFS
static constexpr float LIMITER_CEIL   = 0.989f;

inline float process_limiter(float x) {
    if (!std::isfinite(x)) return 0.0f;
    if (x > LIMITER_THRESH) {
        return LIMITER_CEIL - (x - LIMITER_THRESH) * 0.1f;
    }
    if (x < -LIMITER_THRESH) {
        return -LIMITER_CEIL - (x + LIMITER_THRESH) * 0.1f;
    }
    return x;
}

static inline float db_to_linear(float db) {
    return std::pow(10.0f, db / 20.0f);
}

// ── Tabla seno con interpolación cúbica ───────────────────────────────────────
static constexpr int SIN_TABLE_SIZE = 4096;
alignas(64) static float sin_table[SIN_TABLE_SIZE + 4];
static std::once_flag sin_once;

static void init_sin_table() {
    std::call_once(sin_once, []{
        for (int i = 0; i < SIN_TABLE_SIZE + 4; i++) {
            float phase = TWO_PI * (i - 1) / (float)SIN_TABLE_SIZE;
            sin_table[i] = sinf(phase);
        }
    });
}

static inline float fast_sin(float phase) {
    phase = fmodf(phase, TWO_PI);
    if (phase < 0) phase += TWO_PI;

    float idx = phase * (SIN_TABLE_SIZE * INV_TWO_PI);
    int i = (int)idx;
    float f = idx - i;
    i = (i + 1) & (SIN_TABLE_SIZE - 1);

    float y0 = sin_table[i];
    float y1 = sin_table[i+1];
    float y2 = sin_table[i+2];
    float y3 = sin_table[i+3];
    float c0 = y1;
    float c1 = 0.5f * (y2 - y0);
    float c2 = y0 - 2.5f*y1 + 2.0f*y2 - 0.5f*y3;
    float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
    return ((c3*f + c2)*f + c1)*f + c0;
}

// ── Hyperplane reducido ───────────────────────────────────────────────────────
struct alignas(64) Hyperplane {
    float kalman_state[3];
    uint64_t seq_counter = 0;
    uint8_t active_buffer = 0;
};

// ── Kalman 2-estados ──────────────────────────────────────────────────────────
struct alignas(32) KalmanState {
    float phase = 0.0f;
    float freq = 0.0f;
    float P00 = 0.1f, P01 = 0.0f, P11 = 1.0f;
    float R = 1e-4f;
};

static inline void kalmanInit(KalmanState &k, int sr) {
    k.phase = 0.0f;
    k.freq = 440.0f * TWO_PI / (float)sr;
    k.P00 = 0.1f; k.P01 = 0.0f; k.P11 = 1.0f;
}

static inline float kalmanStep(KalmanState &k, float meas, float dt) {
    const float qPhase = 1e-8f, qFreq = 1e-6f;
    float pred_phase = k.phase + k.freq * dt;
    float pred_freq = k.freq;
    k.P00 += dt*(k.P01 + k.P01 + dt*k.P11) + qPhase;
    k.P01 += dt*k.P11;
    k.P11 += qFreq;
    float y = meas - pred_phase;
    float S = k.P00 + k.R;
    float K0 = k.P00 / S;
    float K1 = k.P01 / S;
    k.phase = pred_phase + K0 * y;
    k.freq = pred_freq + K1 * y;
    k.P00 *= (1.0f - K0);
    k.P01 *= (1.0f - K0);
    k.P11 -= K1 * k.P01;
    return k.phase;
}

// ── Estado global del orquestador ───────────────────────────────────────────
static struct {
    int sampleRate = 48000;
    float gain = 1.0f;
    std::atomic<bool> active{true};
    Hyperplane hyper;
    KalmanState kalman;
    float exciterAmount = 0.0f;
    float eqGain = 0.0f;
    float widthAmount = 0.0f;
    bool bypass = false;
    AntiDolbyState antiDolby;
    float shelfLow[2] = {0.0f, 0.0f};
    float exciterPrevIn[2] = {0.0f, 0.0f};
    float exciterHpState[2] = {0.0f, 0.0f};
    std::atomic<float> lastLufs{-70.0f};
    std::atomic<float> lastPeakDbfs{-96.0f};
} gState;

static inline float sanitize(float x) {
    return std::isfinite(x) ? x : 0.0f;
}

static inline float apply_presence_eq(float x, int channel, float gainDb) {
    if (gainDb == 0.0f) return x;
    const float fc = 1800.0f;
    const float alpha = std::exp(-TWO_PI * fc / (float)gState.sampleRate);
    float low = (1.0f - alpha) * x + alpha * gState.shelfLow[channel];
    gState.shelfLow[channel] = low;
    float high = x - low;
    return low + high * db_to_linear(gainDb);
}

static inline float apply_exciter(float x, int channel, float amount) {
    if (amount <= 0.0f) return x;
    const float fc = 2500.0f;
    const float alpha = std::exp(-TWO_PI * fc / (float)gState.sampleRate);
    float hp = x - gState.exciterPrevIn[channel] + alpha * gState.exciterHpState[channel];
    gState.exciterPrevIn[channel] = x;
    gState.exciterHpState[channel] = hp;
    float harmonics = std::tanh(3.0f * hp) - 0.6f * hp;
    return x + amount * 0.35f * harmonics;
}

static inline void update_metrics(const float* data, int samples) {
    if (!data || samples <= 0) return;
    double sumSq = 0.0;
    float peak = 0.0f;
    for (int i = 0; i < samples; ++i) {
        float s = sanitize(data[i]);
        sumSq += (double)s * (double)s;
        peak = std::max(peak, std::fabs(s));
    }
    float rms = std::sqrt((float)(sumSq / (double)samples) + 1e-12f);
    float lufs = 20.0f * std::log10(std::max(rms, 1e-6f));
    float peakDb = 20.0f * std::log10(std::max(peak, 1e-6f));
    gState.lastLufs.store(lufs, std::memory_order_relaxed);
    gState.lastPeakDbfs.store(peakDb, std::memory_order_relaxed);
}

static inline void process_stereo_frame(float& left, float& right) {
    left = sanitize(left);
    right = sanitize(right);
    if (gState.bypass) return;

    const float widthMul = gState.antiDolby.widenerMultiplier.load(std::memory_order_relaxed);
    const float eqBoost = gState.antiDolby.eqBoost2k4k.load(std::memory_order_relaxed);
    const float width = std::clamp((0.2f + gState.widthAmount * 1.8f) * widthMul, 0.0f, 2.5f);

    left *= gState.gain;
    right *= gState.gain;

    left = apply_presence_eq(left, 0, gState.eqGain + eqBoost);
    right = apply_presence_eq(right, 1, gState.eqGain + eqBoost);

    left = apply_exciter(left, 0, gState.exciterAmount);
    right = apply_exciter(right, 1, gState.exciterAmount);

    float mid = 0.5f * (left + right);
    float side = 0.5f * (left - right) * width;
    left = process_limiter(mid + side);
    right = process_limiter(mid - side);
}

static inline float process_mono_sample(float x) {
    x = sanitize(x);
    if (gState.bypass) return x;
    const float eqBoost = gState.antiDolby.eqBoost2k4k.load(std::memory_order_relaxed);
    x *= gState.gain;
    x = apply_presence_eq(x, 0, gState.eqGain + eqBoost);
    x = apply_exciter(x, 0, gState.exciterAmount);
    return process_limiter(x);
}

// ── JNI: inicialización ───────────────────────────────────────────────────────
extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeInit(JNIEnv* /*env*/, jobject /*thiz*/, jint sampleRate) {
    if (sampleRate <= 0 || sampleRate > 192000) {
        LOGE("nativeInit: sampleRate inválido: %d", sampleRate);
        return;
    }
    gState.sampleRate = sampleRate;
    gState.shelfLow[0] = gState.shelfLow[1] = 0.0f;
    gState.exciterPrevIn[0] = gState.exciterPrevIn[1] = 0.0f;
    gState.exciterHpState[0] = gState.exciterHpState[1] = 0.0f;
    init_sin_table();
    kalmanInit(gState.kalman, sampleRate);
    LOGI("nativeInit: sampleRate=%d, limiter -0.1dB activo", sampleRate);
}

extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetGain(JNIEnv* /*env*/, jobject /*thiz*/, jfloat gain) {
    if (!std::isfinite(gain)) {
        LOGE("nativeSetGain: gain NaN/Inf recibido");
        return;
    }
    gState.gain = std::clamp(gain, 0.0f, 2.0f);
}

extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetExciter(JNIEnv* /*env*/, jobject /*thiz*/, jfloat amount) {
    if (!std::isfinite(amount)) return;
    gState.exciterAmount = std::clamp(amount, 0.0f, 1.0f);
}

extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetEqGain(JNIEnv* /*env*/, jobject /*thiz*/, jfloat gain) {
    if (!std::isfinite(gain)) return;
    gState.eqGain = std::clamp(gain, -12.0f, 12.0f);
}

extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetWidth(JNIEnv* /*env*/, jobject /*thiz*/, jfloat width) {
    if (!std::isfinite(width)) return;
    gState.widthAmount = std::clamp(width, 0.0f, 1.0f);
}

extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetBypass(JNIEnv* /*env*/, jobject /*thiz*/, jboolean bypass) {
    gState.bypass = bypass;
}

extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeProcessAudio(
    JNIEnv* env,
    jobject /*thiz*/,
    jfloatArray inArray,
    jfloatArray outArray,
    jint frames,
    jint channels
) {
    if (inArray == nullptr || outArray == nullptr) {
        LOGE("nativeProcessAudio: array nulo");
        return;
    }
    if (frames <= 0 || frames > 4096) {
        LOGE("nativeProcessAudio: frames inválido: %d", frames);
        return;
    }
    if (channels <= 0 || channels > 8) {
        LOGE("nativeProcessAudio: channels inválido: %d", channels);
        return;
    }
    if (gState.sampleRate <= 0) {
        LOGE("nativeProcessAudio: sampleRate no inicializado");
        return;
    }

    const jsize inLen = env->GetArrayLength(inArray);
    const jsize outLen = env->GetArrayLength(outArray);
    const int requiredIn = frames * channels;
    const int requiredOut = (channels > 2) ? frames * 2 : requiredIn;
    if (inLen < requiredIn || outLen < requiredOut) {
        LOGE("nativeProcessAudio: tamaños inválidos in=%d/%d out=%d/%d",
             (int)inLen, requiredIn, (int)outLen, requiredOut);
        return;
    }

    jfloat* in = env->GetFloatArrayElements(inArray, nullptr);
    jfloat* out = env->GetFloatArrayElements(outArray, nullptr);
    if (in == nullptr || out == nullptr) {
        LOGE("nativeProcessAudio: GetFloatArrayElements falló");
        if (in) env->ReleaseFloatArrayElements(inArray, in, JNI_ABORT);
        if (out) env->ReleaseFloatArrayElements(outArray, out, JNI_ABORT);
        return;
    }

    if (channels > 2) {
        for (int i = 0; i < frames; ++i) {
            int base = i * channels;
            float fl = sanitize(in[base + 0]);
            float fr = sanitize(in[base + 1]);
            float fc = (channels > 2) ? sanitize(in[base + 2]) : 0.0f;
            float bl = (channels > 4) ? sanitize(in[base + 4]) : 0.0f;
            float br = (channels > 5) ? sanitize(in[base + 5]) : 0.0f;
            float sl = (channels > 6) ? sanitize(in[base + 6]) : 0.0f;
            float sr = (channels > 7) ? sanitize(in[base + 7]) : 0.0f;

            float left = fl + 0.7f * fc + 0.5f * sl + 0.3f * bl;
            float right = fr + 0.7f * fc + 0.5f * sr + 0.3f * br;
            process_stereo_frame(left, right);
            out[i * 2 + 0] = left;
            out[i * 2 + 1] = right;
        }
        update_metrics(out, frames * 2);
    } else if (channels == 2) {
        for (int i = 0; i < frames; ++i) {
            float left = in[2 * i + 0];
            float right = in[2 * i + 1];
            process_stereo_frame(left, right);
            out[2 * i + 0] = left;
            out[2 * i + 1] = right;
        }
        update_metrics(out, frames * 2);
    } else {
        for (int i = 0; i < frames; ++i) {
            out[i] = process_mono_sample(in[i]);
        }
        update_metrics(out, frames);
    }

    env->ReleaseFloatArrayElements(inArray, in, JNI_ABORT);
    env->ReleaseFloatArrayElements(outArray, out, 0);
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeGetLufs(JNIEnv* /*env*/, jobject /*thiz*/) {
    return gState.lastLufs.load(std::memory_order_relaxed);
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeGetPeakDbfs(JNIEnv* /*env*/, jobject /*thiz*/) {
    return gState.lastPeakDbfs.load(std::memory_order_relaxed);
}

extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetAntiDolbyScores(
    JNIEnv* /*env*/, jobject /*thiz*/, jfloat speech, jfloat music, jfloat bass
) {
    if (!std::isfinite(speech) || !std::isfinite(music) || !std::isfinite(bass)) {
        LOGE("nativeSetAntiDolbyScores: valores NaN/Inf recibidos");
        return;
    }
    gState.antiDolby.updateFromClassification(
        std::clamp(speech, 0.0f, 1.0f),
        std::clamp(music, 0.0f, 1.0f),
        std::clamp(bass, 0.0f, 1.0f)
    );
}

extern "C" JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetAntiDolbyScoresJni(
    JNIEnv* /*env*/, jclass /*clazz*/, jfloat speech, jfloat music, jfloat bass
) {
    if (!std::isfinite(speech) || !std::isfinite(music) || !std::isfinite(bass)) {
        LOGE("nativeSetAntiDolbyScoresJni: valores NaN/Inf recibidos");
        return;
    }
    gState.antiDolby.updateFromClassification(
        std::clamp(speech, 0.0f, 1.0f),
        std::clamp(music, 0.0f, 1.0f),
        std::clamp(bass, 0.0f, 1.0f)
    );
}

// ── Símbolo externo para el stub JNI ─────────────────────────────────────────
extern "C" void ivanna_set_anti_dolby_scores(float speech, float music, float bass) {
    if (!std::isfinite(speech) || !std::isfinite(music) || !std::isfinite(bass)) return;
    gState.antiDolby.updateFromClassification(
        std::clamp(speech, 0.0f, 1.0f),
        std::clamp(music,  0.0f, 1.0f),
        std::clamp(bass,   0.0f, 1.0f)
    );
}
