# IVANNA Omega — Patch Notes v3.2.3

## Diagnóstico real (línea 434:55)

El error `Unresolved reference: resample` NO era una extension function faltante.
En `PlaybackCaptureService.onCreate()`:

```kotlin
antiDolbyResampler = AudioResampler(48000, 16000)
```

`AudioResampler` es una **CLASE** con método `resample(FloatArray): FloatArray`.
Las v3.2.1 y v3.2.2 creaban extension functions `FloatArray.resample(...)`, que
NO resuelven el call site `resampler.resample(monoIn)` porque `resampler` es
una instancia de clase, no un `FloatArray` receiver.

## Solución (regla de oro: no borrar, pulir)

`AudioResampler.kt` ahora provee:

1. **Clase `AudioResampler(inRate, outRate)`** con:
   - `resample(FloatArray): FloatArray` — el método que faltaba (mono).
   - `resample(FloatArray, channels: Int): FloatArray` — interleaved.
   - Guards: input vacío, rates ≤ 0, fast-path si `inRate == outRate`.
   - Stateless (thread-safe para el hilo de audio).

2. **`companion object AudioResampler.resample(input, inRate, outRate)`**
   para uso sin instanciar.

3. **Extension functions** `FloatArray.resample()` y `ShortArray.resample()`
   preservadas de v3.2.1/v3.2.2 (por si otros call sites las usan).

## Aplicación

Descomprime sobre la raíz del proyecto. Sobrescribe cualquier
`AudioResampler.kt` previa. Sin cambios en Gradle/CMake. Sin imports nuevos
en `PlaybackCaptureService.kt`.

## Resultado esperado

- ✅ `PlaybackCaptureService.kt:434:55` resuelto.
- ✅ Anti-Dolby pipeline (48kHz → 16kHz para YAMNet) operativo.
- ✅ Sin cambios de API para el resto de la cadena DSP.
