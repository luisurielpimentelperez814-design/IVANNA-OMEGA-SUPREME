# IVANNA OMEGA SUPREME — paquete experimental aislado

## Alcance

Este paquete agrega prototipos aislados; **no modifica el audio de producción**. Los nombres “Supersónica”, “Nanosónica” y “Nanotransiénsónica” son etiquetas experimentales del proyecto, no categorías acústicas normalizadas. El procesamiento se limita a la banda audible y a parámetros acotados.

## Brechas confirmadas en el código revisado

1. `SaFOptimizer.kt` elige `selectedSubject` por round-robin y ese identificador solo aparece en el estado/log; no se ha demostrado que seleccione el HRTF usado por el renderer.
2. La métrica `paramNorm` se toma de `SAFCore.getState()[1]`, mientras que `directionEnergies.average()` se usa como error. No deben presentarse como convergencia perceptual medida sin validar el significado de las métricas nativas.
3. `syncToRoomBridge()` fija un target `FloatArray(7) { 0.0f }` y usa RT60 por defecto 0.3 s. Esto es un proxy, no una medición personalizada del usuario/recinto.
4. `HrtfManager::setSafLatentQ()` afecta explícitamente curvatura/azimut en las primeras dimensiones; los comentarios del código describen dimensiones restantes como almacenadas para futura morfología. No asumir que las siete dimensiones modifican filtros reales.
5. La aplicación tiene rutas de audio diferentes (app/JNI y efecto de sistema). La presencia de una clase en una ruta no demuestra que procese la otra.
6. WFS físico requiere geometría y arreglo de altavoces; no debe reportarse como WFS físico si la salida real es binaural por auriculares.

## Archivos

- `cpp/SaFCalibrationGuard.hpp`: valida rangos y separa error direccional de una afirmación de convergencia.
- `cpp/SupersonicSceneCoordinator.hpp`: resuelve backend disponible, limita controles y evita declarar WFS si no está disponible.
- `cpp/NanosonicTransientProcessor.hpp`: procesador RT-safe experimental de microtransitorios, limitado y con fade de 20 ms.
- `android/ExperimentalSpatialLabController.kt`: contrato observable de UI → controlador.
- `android/ExperimentalSpatialLabPanel.kt`: controles Compose activos que llaman al controlador y muestran estado.
- `tests/test_experimental_spatial_audio.cpp`: pruebas host para rangos, fallback y salida finita.

## Integración requerida para cableado real

El panel no debe conectarse a producción hasta implementar un `ExperimentalSpatialLabController` real que:

1. Publique el estado leído del motor, no el último valor escrito por UI.
2. Envíe comandos mediante el control plane ya existente (daemon/control/JNI) y devuelva ACK/estado/error.
3. Añada setters/telemetría JNI para `SupersonicControls` y `NanosonicTransientProcessor`, con símbolos declarados en Kotlin, definición JNI única y fuentes registradas en `CMakeLists.txt`.
4. Publique parámetros a la ruta activa (Route A o Route B); para Route B usar mensajes de control existentes y consumirlos en `omega_effect`/`IvannaFusionCore`, sin hacer llamadas JNI desde el hilo RT.
5. Use estado atómico o snapshot lock-free entre control plane y audio thread; ninguna asignación, mutex, I/O o logging en el callback de audio.
6. Aplique rampas/fades y límites de pico. Bypass debe devolver salida bit-exacta cuando el procesador esté inactivo.
7. Informe `measuredHrtfAvailable`, `physicalWfsAvailable` y backend activo desde detección real de hardware/datasets.

## Secuencia de parche recomendada

A. Corregir el optimizador: no seleccionar sujetos en round-robin como si fuera personalización; introducir selector que confirme que el dataset existe y propague el ID hasta el renderer. Etiquetar la calibración como `proxy` hasta que haya feedback medido.

B. Separar métricas: `directionalError`, `parameterNorm`, `targetResidual`, `datasetId`, `routeId`, `modelLoaded`, `acknowledged`, `lastError`. Convergencia solo si residual medido baja por varias ventanas y ningún canal supera el umbral.

C. Cablear el panel a un adaptador JNI/control daemon; no simular éxito. Los controles de este panel son interfaces, no un adaptador de producción.

D. Activar por feature flag, por defecto OFF. Ejecutar pruebas de símbolos JNI, CMake, RT-safety, latencia, bypass bit-exacto, no clipping y ablation/blind listening antes de promover.

## Pruebas

Compilar prueba host:

```sh
c++ -std=c++17 -Wall -Wextra -Werror tests/test_experimental_spatial_audio.cpp -o /tmp/test_experimental_spatial_audio
/tmp/test_experimental_spatial_audio
```

Después, en el repo completo: correr scripts de wiring JNI, header wiring, RT safety, build flags, CTest y build Android/NDK. Este paquete por sí solo no certifica la integración final ni el resultado perceptual.
