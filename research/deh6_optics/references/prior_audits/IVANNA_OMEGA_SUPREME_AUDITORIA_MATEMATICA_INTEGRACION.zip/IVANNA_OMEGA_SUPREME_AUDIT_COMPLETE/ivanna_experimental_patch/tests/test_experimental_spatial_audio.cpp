#include <cassert>
#include <cmath>
#include <iostream>
#include "../cpp/SaFCalibrationGuard.hpp"
#include "../cpp/SupersonicSceneCoordinator.hpp"
#include "../cpp/NanosonicTransientProcessor.hpp"

int main() {
    using namespace ivanna::experimental;
    SaFCalibrationObservation obs{};
    obs.directionalError = {0.1f, 0.2f, 0.3f, 0.4f, 0.5f};
    obs.rt60Seconds = 0.45f; obs.drrDb = 5.0f; obs.hasMeasuredFeedback = true;
    auto a = SaFCalibrationGuard::assess(obs);
    assert(a.valid && a.hasMeasuredFeedback);
    assert(std::fabs(a.meanError - 0.3f) < 1e-5f);
    obs.directionalError[2] = NAN;
    assert(!SaFCalibrationGuard::assess(obs).valid);

    SupersonicControls c{}; c.enabled = true; c.backend = SpatialBackend::PhysicalWfs;
    c.sceneWidth = 9.0f; c.earlyReflectionMix = NAN;
    auto p = SupersonicSceneCoordinator::makePlan(c, false, true);
    assert(p.backend == SpatialBackend::BinauralHrtf); // fallback truthful about hardware
    assert(p.sceneWidth == 1.0f && p.earlyReflectionMix == 0.15f);
    assert(p.suppressSecondarySpatializer);

    NanosonicTransientProcessor proc;
    proc.prepare(48000.0f); proc.setParams(true, 0.2f, 0.5f);
    float l[256]{}, r[256]{}; l[20] = r[20] = 0.8f;
    proc.process(l, r, 256);
    for (int i = 0; i < 256; ++i) assert(std::isfinite(l[i]) && std::isfinite(r[i]));
    proc.setParams(false, 0.2f, 0.5f);
    proc.process(l, r, 256);
    std::cout << "experimental spatial audio tests passed\n";
}
