#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>

namespace ivanna::experimental {

// Experimental guard: validates observations before they reach the production optimizer.
// It does not claim that a low parameter norm means perceptual convergence.
struct SaFCalibrationObservation {
    std::array<float, 5> directionalError{}; // front/rear/left/right/up, normalized [0,1]
    float rt60Seconds = 0.3f;
    float drrDb = 6.0f;
    bool hasMeasuredFeedback = false;
};

struct SaFCalibrationAssessment {
    bool valid = false;
    bool hasMeasuredFeedback = false;
    float meanError = 1.0f;
    float maxDirectionalError = 1.0f;
    float rt60Seconds = 0.3f;
    float drrDb = 6.0f;
};

class SaFCalibrationGuard final {
public:
    static SaFCalibrationAssessment assess(const SaFCalibrationObservation& in) noexcept {
        SaFCalibrationAssessment out{};
        if (!std::isfinite(in.rt60Seconds) || !std::isfinite(in.drrDb) ||
            in.rt60Seconds < 0.0f || in.rt60Seconds > 5.0f ||
            in.drrDb < -30.0f || in.drrDb > 30.0f) return out;
        float sum = 0.0f, maximum = 0.0f;
        for (float e : in.directionalError) {
            if (!std::isfinite(e) || e < 0.0f || e > 1.0f) return out;
            sum += e;
            maximum = std::max(maximum, e);
        }
        out.valid = true;
        out.hasMeasuredFeedback = in.hasMeasuredFeedback;
        out.meanError = sum / static_cast<float>(in.directionalError.size());
        out.maxDirectionalError = maximum;
        out.rt60Seconds = in.rt60Seconds;
        out.drrDb = in.drrDb;
        return out;
    }
};

} // namespace ivanna::experimental
