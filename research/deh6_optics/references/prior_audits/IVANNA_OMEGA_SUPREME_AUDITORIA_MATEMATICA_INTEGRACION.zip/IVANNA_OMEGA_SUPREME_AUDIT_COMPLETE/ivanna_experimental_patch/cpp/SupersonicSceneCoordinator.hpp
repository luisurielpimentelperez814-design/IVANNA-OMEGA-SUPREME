#pragma once
#include <algorithm>
#include <cmath>

namespace ivanna::experimental {

enum class SpatialBackend { BinauralHrtf, PhysicalWfs, Ambisonics, DirectStereo };

struct SupersonicControls {
    bool enabled = false;
    SpatialBackend backend = SpatialBackend::BinauralHrtf;
    float sceneWidth = 0.35f;       // [0,1]
    float externalization = 0.35f;  // [0,1]
    float earlyReflectionMix = 0.15f; // [0,0.5]
    float lateFieldMix = 0.10f;     // [0,0.5]
    float transitionMs = 80.0f;     // [20,500]
};

struct SupersonicRenderPlan {
    bool enabled = false;
    SpatialBackend backend = SpatialBackend::DirectStereo;
    float sceneWidth = 0.0f;
    float externalization = 0.0f;
    float earlyReflectionMix = 0.0f;
    float lateFieldMix = 0.0f;
    float transitionMs = 80.0f;
    bool suppressSecondarySpatializer = true;
};

inline float finiteClamp(float v, float lo, float hi, float fallback) noexcept {
    return std::isfinite(v) ? std::clamp(v, lo, hi) : fallback;
}

// Control-plane only. The caller applies the plan at a block boundary and performs
// the fade in the audio engine; never allocate or lock from the audio callback.
class SupersonicSceneCoordinator final {
public:
    static SupersonicRenderPlan makePlan(const SupersonicControls& c,
                                         bool physicalWfsAvailable,
                                         bool measuredHrtfAvailable) noexcept {
        SupersonicRenderPlan p{};
        p.enabled = c.enabled;
        p.backend = c.backend;
        p.sceneWidth = finiteClamp(c.sceneWidth, 0.0f, 1.0f, 0.35f);
        p.externalization = finiteClamp(c.externalization, 0.0f, 1.0f, 0.35f);
        p.earlyReflectionMix = finiteClamp(c.earlyReflectionMix, 0.0f, 0.5f, 0.15f);
        p.lateFieldMix = finiteClamp(c.lateFieldMix, 0.0f, 0.5f, 0.10f);
        p.transitionMs = finiteClamp(c.transitionMs, 20.0f, 500.0f, 80.0f);
        // Never silently label headphone binauralization as physical WFS.
        if (p.backend == SpatialBackend::PhysicalWfs && !physicalWfsAvailable)
            p.backend = measuredHrtfAvailable ? SpatialBackend::BinauralHrtf : SpatialBackend::DirectStereo;
        if (p.backend == SpatialBackend::BinauralHrtf && !measuredHrtfAvailable)
            p.backend = SpatialBackend::DirectStereo;
        if (!p.enabled) {
            p.backend = SpatialBackend::DirectStereo;
            p.sceneWidth = p.externalization = p.earlyReflectionMix = p.lateFieldMix = 0.0f;
        }
        // One owner of spatialization per route; RIR may add reflections, not a second panner.
        p.suppressSecondarySpatializer = true;
        return p;
    }
};

} // namespace ivanna::experimental
