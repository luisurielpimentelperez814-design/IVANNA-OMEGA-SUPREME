package com.ivanna.omega.experimental

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Disposable Compose panel. Every control calls the controller; status comes from its StateFlow. */
@Composable
fun ExperimentalSpatialLabPanel(
    controller: ExperimentalSpatialLabController,
    modifier: Modifier = Modifier,
) {
    val s by controller.state.collectAsState()
    Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Laboratorio Supersónico / Nanosónico", style = MaterialTheme.typography.titleLarge)
        Text("Experimental · banda audible · salida segura por defecto", style = MaterialTheme.typography.bodySmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Escena supersónica")
                    Switch(checked = s.enabled, onCheckedChange = controller::setEnabled)
                }
                Text("Motor: ${s.backend} · HRTF medido: ${s.measuredHrtfAvailable} · WFS físico: ${s.physicalWfsAvailable}")
                Text("Anchura de escena: ${"%.2f".format(s.sceneWidth)}")
                Slider(value = s.sceneWidth, onValueChange = controller::setSceneWidth, valueRange = 0f..1f, enabled = s.enabled)
                Text("Externalización: ${"%.2f".format(s.externalization)}")
                Slider(value = s.externalization, onValueChange = controller::setExternalization, valueRange = 0f..1f, enabled = s.enabled)
                Text("Reflexiones tempranas: ${"%.2f".format(s.earlyReflectionMix)}")
                Slider(value = s.earlyReflectionMix, onValueChange = controller::setEarlyReflectionMix, valueRange = 0f..0.5f, enabled = s.enabled)
                Text("Campo tardío: ${"%.2f".format(s.lateFieldMix)}")
                Slider(value = s.lateFieldMix, onValueChange = controller::setLateFieldMix, valueRange = 0f..0.5f, enabled = s.enabled)
            }
        }
        HorizontalDivider()
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Nanosónica / microtransitorios")
                    Switch(checked = s.transientEnabled, onCheckedChange = controller::setTransientEnabled)
                }
                Text("Cantidad limitada: ${"%.2f".format(s.transientAmount)} (máx. 0.35)")
                Slider(value = s.transientAmount, onValueChange = controller::setTransientAmount, valueRange = 0f..0.35f, enabled = s.transientEnabled)
                Text("Mezcla wet: ${"%.2f".format(s.transientWet)}")
                Slider(value = s.transientWet, onValueChange = controller::setTransientWet, valueRange = 0f..1f, enabled = s.transientEnabled)
            }
        }
        Text("Estado: ${s.status}", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = controller::resetToSafeDefaults) { Text("Restaurar valores seguros") }
            TextButton(onClick = { controller.setEnabled(false); controller.setTransientEnabled(false) }) { Text("Bypass") }
        }
    }
}
