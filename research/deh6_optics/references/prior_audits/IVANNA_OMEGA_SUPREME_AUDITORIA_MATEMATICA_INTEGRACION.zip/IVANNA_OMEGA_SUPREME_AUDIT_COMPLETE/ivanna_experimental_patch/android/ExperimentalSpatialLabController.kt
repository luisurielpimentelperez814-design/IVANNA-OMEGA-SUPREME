package com.ivanna.omega.experimental

import kotlinx.coroutines.flow.StateFlow

/**
 * Boundary between the disposable UI and the production JNI/audio route.
 * A production implementation must be supplied by the host app; this interface
 * deliberately does not fake native telemetry or claim audio is active.
 */
data class ExperimentalSpatialLabState(
    val enabled: Boolean = false,
    val backend: SpatialBackend = SpatialBackend.BINAURAL_HRTF,
    val sceneWidth: Float = 0.35f,
    val externalization: Float = 0.35f,
    val earlyReflectionMix: Float = 0.15f,
    val lateFieldMix: Float = 0.10f,
    val transientEnabled: Boolean = false,
    val transientAmount: Float = 0.10f,
    val transientWet: Float = 0.25f,
    val status: String = "No conectado: falta el adaptador JNI de laboratorio",
    val measuredHrtfAvailable: Boolean = false,
    val physicalWfsAvailable: Boolean = false,
)

enum class SpatialBackend { BINAURAL_HRTF, PHYSICAL_WFS, AMBISONICS, DIRECT_STEREO }

interface ExperimentalSpatialLabController {
    val state: StateFlow<ExperimentalSpatialLabState>
    fun setEnabled(enabled: Boolean)
    fun setBackend(backend: SpatialBackend)
    fun setSceneWidth(value: Float)
    fun setExternalization(value: Float)
    fun setEarlyReflectionMix(value: Float)
    fun setLateFieldMix(value: Float)
    fun setTransientEnabled(enabled: Boolean)
    fun setTransientAmount(value: Float)
    fun setTransientWet(value: Float)
    fun resetToSafeDefaults()
}
