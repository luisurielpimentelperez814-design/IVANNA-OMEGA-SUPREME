# IVANNA OMEGA SUPREME — parche experimental descartable

Contenido aislado para revisión, no aplicado al árbol de producción. Ver `docs/INTEGRATION_PLAN.md` antes de integrar.

```sh
c++ -std=c++17 -Wall -Wextra -Werror tests/test_experimental_spatial_audio.cpp -o /tmp/test_experimental_spatial_audio
/tmp/test_experimental_spatial_audio
```

La UI Compose está conectada al contrato `ExperimentalSpatialLabController`, pero todavía necesita un adaptador real hacia JNI/control daemon del repositorio. No se presenta como control de audio operativo hasta que ese adaptador y la telemetría se implementen y verifiquen.
