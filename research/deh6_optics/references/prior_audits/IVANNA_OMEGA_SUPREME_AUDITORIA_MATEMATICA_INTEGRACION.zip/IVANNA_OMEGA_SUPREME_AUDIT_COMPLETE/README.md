# IVANNA OMEGA SUPREME — paquete de auditoría completa (propuesta)

## Contenido
- `AUDITORIA_TECNICA_MATEMATICA.md`: auditoría basada en fuentes del repositorio, ecuaciones, dimensiones, riesgos y criterios de aceptación.
- `patches/SAF_optimizer_audit.patch`: propuesta para validar feedback SAF, evitar personalización round-robin ficticia, dejar de llamar convergencia a `paramNorm`, evitar target latente cero y persistir estado.
- `patches/experimental_architecture_additions.patch`: componentes C++/Kotlin experimentales previamente generados; todavía requieren integración en las rutas de audio del repositorio.
- `ivanna_experimental_patch/`: archivos fuente extraídos del parche experimental para revisar/compilar localmente.
- `patches/prior_closure_bundle.patch` y `evidence/prior_test_results.txt`: historial de entrega anterior para trazabilidad.
- `evidence/current_repository_snapshot.txt`: referencia de la revisión del árbol remoto.

## Pruebas repetidas en esta sesión
Host test compilado con C++20:
```sh
c++ -std=c++20 -Wall -Wextra -Werror ivanna_experimental_patch/tests/test_experimental_spatial_audio.cpp -o /tmp/ivanna_audit_test
/tmp/ivanna_audit_test
```
Resultado: `experimental spatial audio tests passed`.

## Aplicación prudente
1. Crear una rama y confirmar que el checkout está en el commit/base esperado.
2. Revisar `patches/SAF_optimizer_audit.patch`; aplicar solo si el archivo coincide con el contexto:
   `git apply --check patches/SAF_optimizer_audit.patch`
   `git apply patches/SAF_optimizer_audit.patch`
3. No copiar automáticamente los archivos experimentales a la ruta productiva sin revisar `docs/INTEGRATION_PLAN.md` y el grafo de audio actual.
4. Compilar Gradle/NDK, ejecutar tests de JNI/daemon y validar en dispositivo.
5. Mantener Nanosonic desactivado por defecto hasta completar medición de clipping, latencia y escucha A/B.

## Estado y garantía
Este ZIP garantiza la presencia de los artefactos enumerados y que la prueba C++ host indicada pasó en este entorno. No garantiza compilación Android, integración Route A/Route B, latencia real, calidad perceptual universal ni resultados fisiológicos. No se hizo commit ni push.
