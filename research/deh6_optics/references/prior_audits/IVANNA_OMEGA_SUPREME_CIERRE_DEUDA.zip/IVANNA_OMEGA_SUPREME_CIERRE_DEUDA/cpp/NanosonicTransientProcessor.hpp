#pragma once
#include <algorithm>
#include <cmath>

namespace ivanna::experimental {

// Small, bounded transient shaper for A/B research. Audio-thread safe: no allocation,
// mutex, I/O or dynamic dispatch. It is not an ultrasonic processor; it works in-band.
class NanosonicTransientProcessor final {
public:
    void prepare(float sampleRate) noexcept {
        sr_ = (std::isfinite(sampleRate) && sampleRate >= 8000.0f) ? sampleRate : 48000.0f;
        attack_ = 1.0f - std::exp(-1.0f / (0.002f * sr_));
        release_ = 1.0f - std::exp(-1.0f / (0.060f * sr_));
        reset();
    }
    void reset() noexcept { envL_ = envR_ = prevL_ = prevR_ = 0.0f; fade_ = 0.0f; }
    void setParams(bool enabled, float amount, float wet) noexcept {
        enabled_ = enabled;
        amount_ = std::isfinite(amount) ? std::clamp(amount, 0.0f, 0.35f) : 0.0f;
        wet_ = std::isfinite(wet) ? std::clamp(wet, 0.0f, 1.0f) : 0.0f;
    }
    bool isActive() const noexcept { return enabled_ || fade_ > 0.0f; }
    void process(float* left, float* right, int n) noexcept {
        if (!left || !right || n <= 0) return;
        // Contract: fully disabled means bit-exact bypass (no sanitization or writes).
        if (!enabled_ && fade_ <= 0.0f) return;
        const float fadeStep = 1.0f / (0.020f * sr_);
        for (int i = 0; i < n; ++i) {
            fade_ = enabled_ ? std::min(1.0f, fade_ + fadeStep) : std::max(0.0f, fade_ - fadeStep);
            const float xL = std::isfinite(left[i]) ? left[i] : 0.0f;
            const float xR = std::isfinite(right[i]) ? right[i] : 0.0f;
            const float dL = xL - prevL_, dR = xR - prevR_;
            prevL_ = xL; prevR_ = xR;
            const float aL = std::fabs(dL), aR = std::fabs(dR);
            envL_ += (aL > envL_ ? attack_ : release_) * (aL - envL_);
            envR_ += (aR > envR_ ? attack_ : release_) * (aR - envR_);
            // Boost only the transient residual; clamp to avoid runaway peaks.
            const float tL = std::clamp(dL * amount_ * std::min(1.0f, envL_ * 8.0f), -0.25f, 0.25f);
            const float tR = std::clamp(dR * amount_ * std::min(1.0f, envR_ * 8.0f), -0.25f, 0.25f);
            const float yL = xL + wet_ * tL, yR = xR + wet_ * tR;
            left[i] = xL + fade_ * (yL - xL);
            right[i] = xR + fade_ * (yR - xR);
        }
    }
private:
    float sr_ = 48000.0f, attack_ = 0.0f, release_ = 0.0f;
    float envL_ = 0.0f, envR_ = 0.0f, prevL_ = 0.0f, prevR_ = 0.0f;
    float amount_ = 0.0f, wet_ = 0.0f, fade_ = 0.0f;
    bool enabled_ = false;
};

} // namespace ivanna::experimental
