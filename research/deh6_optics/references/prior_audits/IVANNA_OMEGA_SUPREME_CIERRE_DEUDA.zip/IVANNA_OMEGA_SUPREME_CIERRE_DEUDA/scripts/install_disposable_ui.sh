#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-.}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="$REPO/app/src/main/java/com/ivanna/omega/experimental"
mkdir -p "$TARGET"
for f in DaemonSpatialLabController.kt DaemonSpatialLabPanel.kt; do
  if [[ -e "$TARGET/$f" ]]; then echo "Refusing to overwrite $TARGET/$f" >&2; exit 3; fi
  cp "$SRC/app/src/main/java/com/ivanna/omega/experimental/$f" "$TARGET/$f"
done
python3 "$SRC/scripts/patch_saf_optimizer.py" "$REPO/app/src/main/java/com/ivanna/omega/spatial/SaFOptimizer.kt"
echo "Files copied and SAF patch applied. Add DaemonSpatialLabPanel(controller) to a reachable Compose route; see docs/INTEGRATION_AND_VERIFICATION.md."
