#!/usr/bin/env python3
"""Apply conservative SAF correctness fixes; aborts if source anchors differ."""
from pathlib import Path
import sys
p = Path(sys.argv[1] if len(sys.argv) > 1 else "app/src/main/java/com/ivanna/omega/spatial/SaFOptimizer.kt")
s = p.read_text(encoding="utf-8")
changes = [
(""" * paramNorm     : norma del vector de parámetros ‖p_t‖ (convergencia)
 * errorEnergy   : energía de error cuadrático E_t en la iteración actual
""", """ * paramNorm     : métrica publicada por SAFCore.getState()[1]; no equivale por sí sola a convergencia
 * errorEnergy   : media de los cinco errores direccionales aportados por la calibración
"""),
("""    // Tabla mínima de sujetos conocidos (subset CIPIC + MIT).
    // El matching real usará distancia euclidiana sobre head-width / head-depth;
    // por ahora la selección es round-robin sobre esta lista durante la calib.
    // FIX (descableado): IDs corregidos contra el índice IHR1 real
    // (magisk_module/.../hrtf/hrtf_index.json, 11 sujetos deployados).
    // Los anteriores (kemar_subject_165, subject_003/008/009/010/011) no
    // existen en ningún build — selectedSubject solo se consume en el log
    // de este archivo (no llega a JNI ni afecta audio), pero corregirlo
    // evita confusión al leer logs de calibración.
    private val KNOWN_SUBJECTS = listOf(
        // IDs reales del hrtf_index.json deployado (magisk_module/.../hrtf).
        "kemar", "kemar_large", "tu_berlin_kemar",
        "cipic_003", "cipic_008", "cipic_009",
        "cipic_010", "cipic_011", "cipic_012", "cipic_165", "pulse"
    )

""", ""),
("""            // Seleccionar sujeto: round-robin en calibración inicial.
            val subjectIdx = newIteration % KNOWN_SUBJECTS.size
            val subject    = KNOWN_SUBJECTS[subjectIdx]
""", """            // Reportar el sujeto realmente seleccionado por el motor espacial; no simular personalización.
            val subject = runCatching { IvannaSpatialManager.currentHrtfSubject() }
                .getOrDefault("")
"""),
("""            // Target en el espacio latente SAF-Room: dirección de menor error
            // Proxy: vector cero (KEMAR medio) cuando sin datos de calibración
            SaFRoomBridge.setTarget(FloatArray(7) { 0.0f })
            // Ejecutar un paso Φ_SAF-Room^∞ con el contexto actual
""", """            // No sobrescribir el target con cero: no existe una conversión validada
            // de los cinco errores direccionales a un target SOFA latente 7-D.
            // SaFRoomBridge conserva el target/modelo ya configurado y esta calibración
            // debe considerarse proxy hasta que exista feedback medido por dirección.
            // Ejecutar un paso Φ_SAF-Room^∞ con el contexto actual
"""),
("""                convergenceRate = if (st.iteration > 0) st.paramNorm else 1.0f
""", """                // paramNorm procede de SAFCore.getState()[1], no es residual medido.
                // No alimentar ese valor como tasa de convergencia perceptual.
                convergenceRate = 1.0f
"""),
("""    fun runCalibrationStep(directionEnergies: FloatArray) {
        scope.launch {
""", """    fun runCalibrationStep(directionEnergies: FloatArray) {
        // El contrato documentado es exactamente cinco errores normalizados [0,1].
        if (directionEnergies.size != 5 || directionEnergies.any { !it.isFinite() || it < 0f || it > 1f }) {
            Log.w(TAG, "Calibración rechazada: se requieren cinco errores finitos en [0,1]")
            return
        }
        scope.launch {
""")]
for old,new in changes:
    if old not in s:
        print("ERROR: source anchor not found; no changes applied:", old.splitlines()[0], file=sys.stderr)
        sys.exit(2)
    s=s.replace(old,new,1)
p.write_text(s,encoding="utf-8")
print("Applied 6 conservative SAF fixes to",p)
