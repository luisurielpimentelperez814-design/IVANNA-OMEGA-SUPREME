# IVANNA OMEGA SUPREME — cierre de deuda, parche y verificación

## Qué sí queda cableado en este paquete

- `DaemonSpatialLabController` usa `OmegaEngineBridge.requestCommand()` en `Dispatchers.IO`, no `sendCommand()` desde el hilo UI (el último puede retornar solo el estado de conexión al encolar). El estado de UI se actualiza con la respuesta del daemon y muestra ACK/status/consumer/generation.
- WFS usa el comando existente `SET_WFS` (`wfsEnabled`, `wfsSpread`). **WFS solo debe activarse con arreglo físico/geometría calibrados**; no equivale a espacialización binaural en auriculares.
- Campo temporal usa `SET_TEMPORAL_FIELD` (`temporalEnabled`, `temporalAmount`, `temporalAuto`).
- Sala usa `SET_ROOM_RT60` (`rt60`, `wet`, `idx`).
- Ataque/impacto usa `SET_PUNCH` existente. La UI lo etiqueta como tal: no afirma que el nuevo procesador Nanosónico esté ya insertado en audio.
- El parche SAF rechaza cinco energías inválidas, deja de seleccionar sujetos HRTF por round-robin, deja de escribir un target latente artificialmente cero y no confunde `paramNorm` con tasa de convergencia.
- El procesador Nanosónico autónomo mejora el bypass: cuando está desactivado y sin cola de fade, no escribe al búfer (bit-exact bypass).

## Integración de la pantalla

La app tiene múltiples rutas y no se ha adivinado un destino de navegación. El paquete incluye `ExperimentalSpatialLabScreen()` que crea/cierra el controlador y llama `refreshConnection()` al entrar. Añade esa pantalla como destino en el grafo de navegación ya existente; no inventes una segunda navegación paralela. Si el proyecto usa ViewModel para pantallas, migra el ciclo de vida del controlador al ViewModel antes de producción.

## Limitaciones que siguen siendo reales

1. El nuevo `NanosonicTransientProcessor.hpp` aún no es consumido por `IvannaFusionCore` ni por la Ruta A JNI. No se le atribuye efecto audible desde la UI. El control Punch sí es un control real del motor existente, pero no sustituye el nuevo DSP.
2. El selector de backend Supersónico en el prototipo de investigación no detecta por sí solo hardware. La pantalla productiva expone el WFS existente, no miente sobre HRTF medido ni sobre WFS físico disponible.
3. Los comandos del daemon pueden responder `accepted_pending_consumer`; esto no equivale a confirmación de que el bloque DSP ya cambió. La UI enseña el estado de respuesta para distinguirlo.
4. El target SAF personalizado no puede calcularse solo con cinco números de error sin un modelo validado de mapeo a siete coordenadas. El parche elimina el target cero artificial, pero la personalización real requiere feedback medido y una fuente de target definida.
5. No se han podido compilar APK/NDK ni ejecutar el daemon en hardware desde este entorno. No declarar producción ni “1000%” hasta correr las verificaciones abajo.

## Pruebas ejecutables incluidas

```sh
c++ -std=c++17 -Wall -Wextra -Werror tests/test_experimental_spatial_audio.cpp -o /tmp/test_experimental_spatial_audio
/tmp/test_experimental_spatial_audio
```

En el checkout real, además ejecutar:

```sh
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
# Ejecutar los scripts si existen en este checkout:
python3 scripts/check_jni_wiring.py
python3 scripts/check_header_wiring.py
python3 scripts/check_rt_safety.py
python3 scripts/check_build_flags.py
ctest --test-dir <directorio-build-host> --output-on-failure
```

Las rutas/targets pueden variar en el checkout; no omitir los que no existan sin registrar la razón. Probar en dos rutas (app/JNI y efecto de sistema) y comprobar: ACK del daemon, consumer activo, bypass, no clipping/true peak, latencia, transiciones sin clic, y A/B ciego con nivel igualado.

## Matriz de estado

| Área | Estado del paquete | Evidencia necesaria para producción |
|---|---|---|
| WFS / temporal / sala / Punch UI → daemon | Adaptador implementado sobre comandos existentes | ACK `applied`, consumer activo y cambio observado en DSP |
| SAF calibración | Parche de saneamiento preparado | Build Android, tests SAF y datos reales de calibración |
| HRTF personalizado | No declarado cerrado | ID del dataset validado y aplicado al renderer real |
| Nanosonic DSP | Header standalone probado; no insertado en ruta productiva | Integración en Route A/B, control plane, telemetría, RT-safety y pruebas de audio |
| Supersonic coordinator | Lógica de planificación aislada | Integración con una sola autoridad espacial por ruta y hardware real |
| Percepción/beneficio | No declarado | Prueba A/B ciega, nivel igualado y métricas predefinidas |

## Rollback

Los archivos son aditivos. Para retirar la UI, eliminar `app/src/main/java/com/ivanna/omega/experimental/DaemonSpatialLabController.kt` y `DaemonSpatialLabPanel.kt`; para revertir el saneamiento SAF, restaurar el archivo desde Git. Los headers nuevos no están conectados a producción por defecto.
