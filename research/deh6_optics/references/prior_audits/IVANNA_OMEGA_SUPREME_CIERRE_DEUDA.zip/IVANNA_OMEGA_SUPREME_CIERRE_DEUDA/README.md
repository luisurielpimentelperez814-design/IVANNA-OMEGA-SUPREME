# IVANNA OMEGA SUPREME — paquete de saneamiento e integración

Este paquete separa **cambios seguros ya preparados** de **integraciones que no deben fingirse como terminadas**.

- `app/src/main/java/com/ivanna/omega/experimental/`: panel Compose y adaptador a comandos reales existentes del daemon.
- `cpp/`: guard SAF, coordinador Supersónico y procesador Nanosónico aislado.
- `tests/`: pruebas host de C++.
- `scripts/patch_saf_optimizer.py`: parche con validación de anclas, no aplica si el archivo fuente difiere.
- `scripts/install_disposable_ui.sh`: copia dos archivos nuevos y aplica el saneamiento SAF; no sobrescribe archivos existentes.
- `docs/INTEGRATION_AND_VERIFICATION.md`: mapa de integración, límites, comandos de prueba y rollback.

## Prueba host

```sh
c++ -std=c++17 -Wall -Wextra -Werror tests/test_experimental_spatial_audio.cpp -o /tmp/test_experimental_spatial_audio
/tmp/test_experimental_spatial_audio
```

## Importante

No es honesto afirmar 100% de integración: el procesador Nanosónico nuevo todavía no está insertado en Route A/Route B y no se ejecutó build Android/NDK ni prueba auditiva de dispositivo en este entorno. El panel productivo sí manda comandos existentes `SET_WFS`, `SET_TEMPORAL_FIELD`, `SET_ROOM_RT60`, `SET_PUNCH` y muestra respuesta del daemon. Revisa las limitaciones antes de activar WFS.
