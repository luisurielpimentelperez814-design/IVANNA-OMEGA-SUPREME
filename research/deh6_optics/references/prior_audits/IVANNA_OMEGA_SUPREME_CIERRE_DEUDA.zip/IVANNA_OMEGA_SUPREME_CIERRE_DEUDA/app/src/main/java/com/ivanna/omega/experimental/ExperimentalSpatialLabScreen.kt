package com.ivanna.omega.experimental

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember

/** Standalone screen target to add to the app's existing navigation graph. */
@Composable
fun ExperimentalSpatialLabScreen() {
    val controller = remember { DaemonSpatialLabController() }
    DisposableEffect(controller) {
        onDispose { controller.close() }
    }
    LaunchedEffect(controller) { controller.refreshConnection() }
    DaemonSpatialLabPanel(controller = controller)
}
