package com.ivanna.omega.experimental

import com.ivanna.omega.magisk.OmegaEngineBridge
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * UI adapter for control-plane commands already implemented by the daemon.
 * Every status update is based on a daemon reply; a queued UI value is not called "applied".
 * This adapter controls existing WFS/temporal-field/room/punch commands. It does NOT
 * pretend the new standalone NanosonicTransientProcessor is connected to Route A/B.
 */
class DaemonSpatialLabController : AutoCloseable {
    data class State(
        val wfsEnabled: Boolean = false,
        val wfsSpread: Float = 0.5f,
        val temporalEnabled: Boolean = false,
        val temporalAmount: Float = 0f,
        val roomRt60Seconds: Float = 0.3f,
        val roomWet: Float = 0f,
        val punchAmount: Float = 0f,
        val daemonConnected: Boolean = false,
        val lastCommand: String = "—",
        val lastAck: Boolean? = null,
        val generation: Long = 0L,
        val consumer: String = "unknown",
        val status: String = "Sin comprobar: esperando el primer comando"
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private val jobs = mutableMapOf<String, Job>()

    fun refreshConnection() = submit("GET_ROOM_STATUS", JSONObject().put("action", "GET_ROOM_STATUS"), update = { s, r ->
        s.copy(daemonConnected = r.optBoolean("ok", false), status = replyStatus(r, "HELLO"))
    })

    fun setWfsEnabled(enabled: Boolean) {
        _state.value = _state.value.copy(wfsEnabled = enabled)
        sendLatest("SET_WFS", JSONObject().put("action", "SET_WFS")
            .put("wfsEnabled", if (enabled) 1 else 0).put("wfsSpread", _state.value.wfsSpread)) { s, r ->
            s.copy(wfsEnabled = r.optBoolean("ok", false) && enabled,
                daemonConnected = true, status = replyStatus(r, "SET_WFS"))
        }
    }

    fun setWfsSpread(value: Float) {
        val v = finiteClamp(value, 0f, 2f, 0.5f)
        _state.value = _state.value.copy(wfsSpread = v)
        sendLatest("SET_WFS", JSONObject().put("action", "SET_WFS")
            .put("wfsEnabled", if (_state.value.wfsEnabled) 1 else 0).put("wfsSpread", v)) { s, r ->
            s.copy(daemonConnected = true, status = replyStatus(r, "SET_WFS"))
        }
    }

    fun setTemporalEnabled(enabled: Boolean) {
        _state.value = _state.value.copy(temporalEnabled = enabled)
        sendLatest("SET_TEMPORAL_FIELD", temporalPayload(enabled, _state.value.temporalAmount)) { s, r ->
            s.copy(temporalEnabled = r.optBoolean("ok", false) && enabled,
                daemonConnected = true, status = replyStatus(r, "SET_TEMPORAL_FIELD"))
        }
    }

    fun setTemporalAmount(value: Float) {
        val v = finiteClamp(value, 0f, 1f, 0f)
        _state.value = _state.value.copy(temporalAmount = v)
        sendLatest("SET_TEMPORAL_FIELD", temporalPayload(_state.value.temporalEnabled, v)) { s, r ->
            s.copy(daemonConnected = true, status = replyStatus(r, "SET_TEMPORAL_FIELD"))
        }
    }

    fun setRoom(rt60Seconds: Float = _state.value.roomRt60Seconds, wet: Float = _state.value.roomWet) {
        val rt = finiteClamp(rt60Seconds, 0.18f, 1.8f, 0.3f)
        val w = finiteClamp(wet, 0f, 1f, 0f)
        _state.value = _state.value.copy(roomRt60Seconds = rt, roomWet = w)
        sendLatest("SET_ROOM_RT60", JSONObject().put("action", "SET_ROOM_RT60")
            .put("rt60", rt).put("wet", w).put("idx", -1)) { s, r ->
            s.copy(daemonConnected = true, status = replyStatus(r, "SET_ROOM_RT60"))
        }
    }

    /** Uses the existing SET_PUNCH effect as an honest attack/impact proxy, not the new custom processor. */
    fun setPunchAmount(value: Float) {
        val v = finiteClamp(value, 0f, 1f, 0f)
        _state.value = _state.value.copy(punchAmount = v)
        sendLatest("SET_PUNCH", JSONObject().put("action", "SET_PUNCH").put("punchAmount", v)) { s, r ->
            s.copy(daemonConnected = true, status = replyStatus(r, "SET_PUNCH"))
        }
    }

    fun resetSafeDefaults() {
        _state.value = _state.value.copy(wfsEnabled = false, temporalEnabled = false,
            temporalAmount = 0f, roomWet = 0f, punchAmount = 0f)
        setWfsEnabled(false)
        setTemporalEnabled(false)
        setTemporalAmount(0f)
        setRoom(wet = 0f)
        setPunchAmount(0f)
    }

    private fun temporalPayload(enabled: Boolean, amount: Float) = JSONObject()
        .put("action", "SET_TEMPORAL_FIELD")
        .put("temporalEnabled", if (enabled) 1 else 0)
        .put("temporalAmount", finiteClamp(amount, 0f, 1f, 0f))
        .put("temporalAuto", 0)

    private fun sendLatest(action: String, payload: JSONObject, update: (State, JSONObject) -> State) {
        jobs[action]?.cancel()
        jobs[action] = scope.launch {
            val reply = runCatching { OmegaEngineBridge.requestCommand(payload) }.getOrNull()
            if (reply == null) {
                _state.value = _state.value.copy(daemonConnected = false, lastCommand = action,
                    lastAck = false, status = "$action: sin respuesta del daemon; no se confirma aplicación")
                return@launch
            }
            val ok = reply.optBoolean("ok", false)
            val applied = reply.optBoolean("applied", ok)
            val generation = reply.optLong("generation", reply.optLong("gen", _state.value.generation))
            val consumer = reply.optString("consumer", "unknown")
            _state.value = update(_state.value, reply).copy(lastCommand = action,
                lastAck = ok && applied, generation = generation, consumer = consumer,
                daemonConnected = true, status = replyStatus(reply, action))
        }
    }

    private fun submit(action: String, payload: JSONObject, update: (State, JSONObject) -> State) =
        sendLatest(action, payload, update)

    override fun close() { jobs.values.forEach { it.cancel() }; scope.cancel() }

    private fun replyStatus(reply: JSONObject, action: String): String {
        val ok = reply.optBoolean("ok", false)
        val applied = reply.optBoolean("applied", ok)
        val status = reply.optString("status", if (applied) "applied" else "rejected/unknown")
        val consumer = reply.optString("consumer", "unknown")
        val generation = reply.optLong("generation", -1L)
        return "$action · ${if (ok && applied) "ACK" else "sin ACK de aplicación"} · $status · consumer=$consumer · gen=$generation"
    }

    private fun finiteClamp(v: Float, min: Float, max: Float, fallback: Float) =
        if (v.isFinite()) v.coerceIn(min, max) else fallback
}
