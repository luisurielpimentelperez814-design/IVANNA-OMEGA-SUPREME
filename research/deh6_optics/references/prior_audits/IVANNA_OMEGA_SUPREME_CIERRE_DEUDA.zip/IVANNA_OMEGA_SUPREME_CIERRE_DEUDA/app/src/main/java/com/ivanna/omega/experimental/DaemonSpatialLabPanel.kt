package com.ivanna.omega.experimental

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Panel for already-existing daemon commands. WFS requires a calibrated speaker array. */
@Composable
fun DaemonSpatialLabPanel(controller: DaemonSpatialLabController, modifier: Modifier = Modifier) {
    val s by controller.state.collectAsState()
    Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("IVANNA · Laboratorio espacial", style = MaterialTheme.typography.titleLarge)
        Text("Controles existentes del daemon · los ACK reflejan la respuesta de control, no una prueba perceptual", style = MaterialTheme.typography.bodySmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("WFS · arreglo físico calibrado")
                    Switch(checked = s.wfsEnabled, onCheckedChange = controller::setWfsEnabled)
                }
                Text("Spread WFS: ${"%.2f".format(s.wfsSpread)}")
                Slider(value = s.wfsSpread, onValueChange = controller::setWfsSpread, valueRange = 0f..2f)
                Text("Activa WFS solo con la geometría y el arreglo de altavoces correctos.", style = MaterialTheme.typography.bodySmall)
            }
        }
        HorizontalDivider()
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Campo temporal")
                    Switch(checked = s.temporalEnabled, onCheckedChange = controller::setTemporalEnabled)
                }
                Text("Cantidad: ${"%.2f".format(s.temporalAmount)}")
                Slider(value = s.temporalAmount, onValueChange = controller::setTemporalAmount, valueRange = 0f..1f, enabled = s.temporalEnabled)
            }
        }
        HorizontalDivider()
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Sala RIR existente")
                Text("RT60: ${"%.2f".format(s.roomRt60Seconds)} s")
                Slider(value = s.roomRt60Seconds, onValueChange = { controller.setRoom(rt60Seconds = it) }, valueRange = 0.18f..1.8f)
                Text("Wet: ${"%.2f".format(s.roomWet)}")
                Slider(value = s.roomWet, onValueChange = { controller.setRoom(wet = it) }, valueRange = 0f..1f)
            }
        }
        HorizontalDivider()
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Ataque / impacto · SET_PUNCH existente")
                Text("Cantidad: ${"%.2f".format(s.punchAmount)}")
                Slider(value = s.punchAmount, onValueChange = controller::setPunchAmount, valueRange = 0f..1f)
                Text("Esto controla el motor Punch existente; no equivale a tener el nuevo NanosonicTransientProcessor integrado.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Text("Daemon: ${if (s.daemonConnected) "conectado" else "sin confirmar"} · último comando: ${s.lastCommand} · ACK: ${s.lastAck} · consumer: ${s.consumer} · generación: ${s.generation}", style = MaterialTheme.typography.bodySmall)
        Text(s.status, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = controller::refreshConnection) { Text("Comprobar daemon") }
            TextButton(onClick = controller::resetSafeDefaults) { Text("Valores seguros") }
        }
    }
}
