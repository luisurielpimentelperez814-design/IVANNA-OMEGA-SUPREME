#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include "../cpp/SaFCalibrationGuard.hpp"
#include "../cpp/SupersonicSceneCoordinator.hpp"
#include "../cpp/NanosonicTransientProcessor.hpp"

int main() {
    using namespace ivanna::experimental;
    SaFCalibrationObservation obs{};
    obs.directionalError = {0.1f, 0.2f, 0.3f, 0.4f, 0.5f};
    obs.rt60Seconds = 0.45f; obs.drrDb = 5.0f; obs.hasMeasuredFeedback = true;
    auto a = SaFCalibrationGuard::assess(obs);
    assert(a.valid && a.hasMeasuredFeedback);
    assert(std::fabs(a.meanError - 0.3f) < 1e-5f);
    obs.directionalError[2] = NAN;
    assert(!SaFCalibrationGuard::assess(obs).valid);
    obs.directionalError[2] = 0.2f; obs.rt60Seconds = 6.0f;
    assert(!SaFCalibrationGuard::assess(obs).valid);

    SupersonicControls c{}; c.enabled = true; c.backend = SpatialBackend::PhysicalWfs;
    c.sceneWidth = 9.0f; c.earlyReflectionMix = NAN;
    auto plan = SupersonicSceneCoordinator::makePlan(c, false, true);
    assert(plan.backend == SpatialBackend::BinauralHrtf);
    assert(plan.sceneWidth == 1.0f && plan.earlyReflectionMix == 0.15f);
    assert(plan.suppressSecondarySpatializer);
    plan = SupersonicSceneCoordinator::makePlan(c, false, false);
    assert(plan.backend == SpatialBackend::DirectStereo);
    c.enabled = false;
    plan = SupersonicSceneCoordinator::makePlan(c, true, true);
    assert(plan.backend == SpatialBackend::DirectStereo && plan.sceneWidth == 0.0f);

    NanosonicTransientProcessor proc;
    proc.prepare(48000.0f);
    // Bit-exact bypass includes NaN payload preservation because the processor must not touch buffers.
    float l[256]{}, r[256]{}; l[20] = r[20] = 0.8f;
    l[4] = NAN;
    float originalL[256], originalR[256];
    std::memcpy(originalL, l, sizeof(l)); std::memcpy(originalR, r, sizeof(r));
    proc.process(l, r, 256);
    assert(std::memcmp(originalL, l, sizeof(l)) == 0);
    assert(std::memcmp(originalR, r, sizeof(r)) == 0);
    proc.setParams(true, 0.2f, 0.5f);
    proc.process(l, r, 256);
    for (int i = 0; i < 256; ++i) assert(std::isfinite(l[i]) && std::isfinite(r[i]));
    proc.setParams(false, 0.2f, 0.5f);
    proc.process(l, r, 256); // fade out, remains finite
    for (int i = 0; i < 256; ++i) assert(std::isfinite(l[i]) && std::isfinite(r[i]));
    std::cout << "experimental spatial audio tests passed\n";
}
