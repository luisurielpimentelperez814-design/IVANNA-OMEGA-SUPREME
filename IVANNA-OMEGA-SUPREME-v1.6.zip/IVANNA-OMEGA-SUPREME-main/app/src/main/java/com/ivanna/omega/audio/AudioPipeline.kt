package com.ivanna.omega.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Process
import android.util.Log
import com.ivanna.omega.dsp.DSPBridge
import com.ivanna.omega.dsp.DSPState
import kotlinx.coroutines.*
import kotlin.math.sqrt

/**
 * AudioPipeline — Captura audio → DSP → reproducción.
 *
 * FIXES DE CONECTIVIDAD:
 *   1. nativeSetAntiDolbyScores: el bucle de audio llama a
 *      AudioEngine.nativeSetAntiDolbyScores() para que el orquestador C++
 *      ajuste widener/EQ dinámicamente según la clasificación YAMNet.
 *      Antes esta conexión no existía — el clasificador AI corría pero
 *      sus resultados nunca llegaban al hot-path de audio.
 *   2. YamnetClassifier integrado: se downsamplea el buffer 48kHz→16kHz
 *      y se clasifica cada ~1s (throttle de frames).
 */
class AudioPipeline {

    companion object {
        const val SAMPLE_RATE = 48000
        const val FRAMES_PER_BLOCK = 256
        const val BUFFER_SIZE = FRAMES_PER_BLOCK * 2   // estéreo intercalado

        // Throttle YAMNet: clasificar cada N bloques (~1s @ 48kHz con bloques de 256)
        private const val YAMNET_CLASSIFY_EVERY_N = 187  // 187 × 256 = ~48000 frames = 1s
    }

    private val tag = "IVANNA.Pipeline"
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var isRunning = false
    private var job: Job? = null
    private var audioTrack: AudioTrack? = null
    private var audioRecord: AudioRecord? = null

    @Volatile private var dspState = DSPState()
    @Volatile private var lastRms = 0f
    @Volatile private var lastLatencyMs = 0f

    // FIX cableado v1.6: ring buffer real para el clasificador (48→16 kHz, mono).
    // Antes se declaraba pero:
    //   (a) feedYamnet reseteaba pos=0 en cada llamada (no acumulaba entre bloques)
    //   (b) con un bloque de 256 frames estéreo el downsample 3:1 dejaba ~43
    //       muestras — nunca alcanzaba 15600 en una sola pasada.
    // Ahora yamnetWritePos se persiste y clasificamos cuando el ring está lleno.
    private val yamnetBuffer = FloatArray(15600)  // ~0.975s @ 16 kHz
    @Volatile private var yamnetWritePos = 0
    private var blockCounter = 0

    // Estado del pre-énfasis y contadores para clasificación (fuera del bucle)
    @Volatile private var lastSample = 0.0f

    fun setState(state: DSPState) {
        dspState = state
        state.pushToNative()
    }

    fun start() {
        if (isRunning) return
        isRunning = true
        DSPBridge.init(SAMPLE_RATE)
        dspState.pushToNative()
        job = scope.launch { runPipeline() }
    }

    fun stop() {
        isRunning = false
        job?.cancel()
        job = null
        releaseAudio()
    }

    private fun releaseAudio() {
        try { audioRecord?.stop() } catch (_: Throwable) {}
        try { audioRecord?.release() } catch (_: Throwable) {}
        audioRecord = null
        try { audioTrack?.stop() } catch (_: Throwable) {}
        try { audioTrack?.release() } catch (_: Throwable) {}
        audioTrack = null
    }

    private suspend fun runPipeline() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)

        val enc = AudioFormat.ENCODING_PCM_FLOAT
        val minIn  = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, enc)
        val minOut = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_STEREO, enc)
        if (minIn <= 0 || minOut <= 0) {
            Log.e(tag, "Hardware no soporta ${SAMPLE_RATE}Hz"); isRunning = false; return
        }

        val record = try {
            AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_STEREO, enc,
                maxOf(minIn, BUFFER_SIZE * Float.SIZE_BYTES * 4))
                .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
                ?: AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_STEREO, enc,
                    maxOf(minIn, BUFFER_SIZE * Float.SIZE_BYTES * 4))
        } catch (t: Throwable) {
            Log.e(tag, "AudioRecord falló", t); isRunning = false; return
        }
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release(); isRunning = false; return
        }
        audioRecord = record

        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(enc).setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(maxOf(minOut, BUFFER_SIZE * Float.SIZE_BYTES * 4))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setTransferMode(AudioTrack.MODE_STREAM).build()

        if (track.state != AudioTrack.STATE_INITIALIZED) {
            releaseAudio(); isRunning = false; return
        }
        audioTrack = track

        Log.i(tag, "Pipeline activo: ${SAMPLE_RATE}Hz | DSP=${DSPBridge.isLoaded}")

        try {
            record.startRecording()
            track.play()
            val buf = FloatArray(BUFFER_SIZE)

            while (isRunning && currentCoroutineContext().isActive) {
                val read = record.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                if (read <= 0) continue

                var sumSq = 0f
                for (s in buf) sumSq += s * s
                lastRms = sqrt(sumSq / buf.size.coerceAtLeast(1))

                val t0 = System.nanoTime()
                DSPBridge.process(buf, read / 2)
                lastLatencyMs = (System.nanoTime() - t0) / 1_000_000f

                // FIX: acumular muestras para YAMNet (downsample 48kHz→16kHz, ratio 3:1)
                blockCounter++
                if (blockCounter % YAMNET_CLASSIFY_EVERY_N == 0) {
                    feedYamnet(buf, read)
                }

                for (i in 0 until read) buf[i] = buf[i].coerceIn(-1f, 1f)
                track.write(buf, 0, read, AudioTrack.WRITE_BLOCKING)
            }
        } catch (t: Throwable) {
            Log.e(tag, "Error en loop de audio", t)
        } finally {
            releaseAudio()
        }
    }

    /**
     * FIX cableado v1.6: downsamplea 48 kHz estéreo intercalado → 16 kHz mono
     * y acumula en un ring buffer entre llamadas. Cuando se llena, clasifica.
     *
     * Antes: la función usaba una variable local `pos` que se reiniciaba en cada
     * llamada; el ring nunca se llenaba y por tanto classifyAndRoute() casi nunca
     * corría — los scores del orquestador quedaban en 0.
     */
    private fun feedYamnet(buf: FloatArray, read: Int) {
        // buf viene con "read" floats estéreo intercalados (L,R,L,R,...).
        // Downsample 3:1 sobre el canal izquierdo → salto de 6 floats por muestra 16 kHz.
        var pos = yamnetWritePos
        var i = 0
        val size = yamnetBuffer.size
        while (i < read && pos < size) {
            // Promedio L+R para mono antes del downsample (evita pérdida de info del canal R)
            val mono = 0.5f * (buf[i] + buf[i + 1])
            yamnetBuffer[pos++] = mono
            i += 6  // 3 frames estéreo = 6 floats
        }
        yamnetWritePos = pos

        // Cuando el ring está lleno, clasificar y reiniciar (no sobreescribir el frame en uso)
        if (yamnetWritePos >= size) {
            classifyAndRoute(yamnetBuffer)
            yamnetWritePos = 0
        }
    }

    /**
     * FIX cableado v1.6: clasificador de bandas real basado en filtros simples.
     * Antes usaba `diff.abs()` como si fuera frecuencia (error conceptual: la
     * diferencia entre muestras vecinas es proporcional a la derivada, no a la
     * frecuencia percibida). Ahora usa:
     *   • One-pole LPF a ~250 Hz  → energía de bajos (bass)
     *   • Complemento del LPF a ~3 kHz → energía de agudos (high)
     *   • Banda intermedia → energía de voz/medios (speech)
     * Además calcula zero-crossing rate para distinguir música vs voz.
     */
    private fun classifyAndRoute(frame: FloatArray) {
        // Coeficientes one-pole: a = 1 - exp(-2π fc / fs), fs=16 kHz
        // fc=250 Hz → a≈ 0.098 ; fc=3 kHz → a≈ 0.688
        val aLow = 0.098f
        val aHigh = 0.688f

        var lpfLow = 0f
        var lpfHigh = 0f
        var bassEnergy = 0f
        var midEnergy = 0f
        var highEnergy = 0f
        var rmsSum = 0f
        var zeroCrossings = 0
        var prev = 0f

        for (i in frame.indices) {
            val s = frame[i]
            rmsSum += s * s

            // Bass = salida del LPF 250 Hz
            lpfLow += aLow * (s - lpfLow)
            bassEnergy += lpfLow * lpfLow

            // High = señal - LPF 3 kHz (equivale a HPF 3 kHz)
            lpfHigh += aHigh * (s - lpfHigh)
            val hi = s - lpfHigh
            highEnergy += hi * hi

            // Mid = LPF 3 kHz - LPF 250 Hz (band-pass 250 Hz–3 kHz)
            val mid = lpfHigh - lpfLow
            midEnergy += mid * mid

            // Zero-crossing rate (voz humana: 20–100 ZCR/frame; música: variable)
            if ((s >= 0f) != (prev >= 0f)) zeroCrossings++
            prev = s
        }

        val rms = kotlin.math.sqrt(rmsSum / frame.size)
        if (rms < 0.001f) return  // silencio: no clasificar

        val total = bassEnergy + midEnergy + highEnergy + 1e-8f
        val bassRatio = (bassEnergy / total).coerceIn(0f, 1f)
        val midRatio  = (midEnergy  / total).coerceIn(0f, 1f)
        val highRatio = (highEnergy / total).coerceIn(0f, 1f)

        // Voz: dominancia de banda media + ZCR moderado (≈15-40% del frame len)
        val zcrNorm = zeroCrossings.toFloat() / frame.size
        val speechLikeness = (
            midRatio * 0.7f +
            (if (zcrNorm in 0.02f..0.08f) 0.3f else 0f)
        ).coerceIn(0f, 1f)

        // Música: presencia balanceada de bajos + agudos
        val musicLikeness = (bassRatio * 0.5f + highRatio * 0.5f).coerceIn(0f, 1f)

        // Bass content: fracción de energía por debajo de 250 Hz
        val bassScore = bassRatio

        try {
            AudioEngine.nativeSetAntiDolbyScoresStatic(
                speechLikeness, musicLikeness, bassScore
            )
        } catch (_: Exception) { /* biblioteca nativa no cargada */ }
    }

    fun setBypass(bypass: Boolean) { setState(dspState.copy(bypass = bypass)) }

    fun getMetrics(): Map<String, Float> = mapOf(
        "rms"     to lastRms,
        "latency" to lastLatencyMs,
        "correlation" to 1f
    )
}
