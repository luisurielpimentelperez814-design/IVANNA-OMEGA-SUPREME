/*
 * ivanna_jni_stub.cpp — Puente estático @JvmStatic → orquestador C++
 *
 * FIX CABLEADO Anti-Dolby v1.6 (crítico):
 *   Antes este stub sólo hacía LOGI y descartaba los scores YAMNet enviados
 *   desde AudioPipeline.classifyAndRoute() → AudioEngine.nativeSetAntiDolbyScoresStatic().
 *   Resultado: la ruta @JvmStatic (companion object) llegaba hasta aquí, se logueaba,
 *   y **nunca** llamaba al AntiDolbyState → widenerMultiplier / eqBoost2k4k del orquestador.
 *
 *   Ahora reenvía los scores a la función símbolo externa
 *   `ivanna_set_anti_dolby_scores(speech, music, bass)` implementada en
 *   audio_orchestrator.cpp, que sí actualiza gState.antiDolby y por tanto sí
 *   afecta al hot-path de procesamiento.
 *
 *   El mismo binding también implementa nativeSetAntiDolbyEnabledJni() para
 *   activar/desactivar el modo Anti-Dolby desde la UI (toggle en MainActivity).
 */
#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <algorithm>

#define LOG_TAG "IVANNA-Stub"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Símbolos exportados por audio_orchestrator.cpp — puente al gState.antiDolby real
extern "C" void ivanna_set_anti_dolby_scores(float speech, float music, float bass);
extern "C" void ivanna_set_anti_dolby_enabled(int enabled);

extern "C" {

/**
 * Ruta estática (companion @JvmStatic) desde AudioPipeline en el hot-path de audio.
 * Envía scores YAMNet (speech/music/bass) al orquestador para que ajuste
 * widenerMultiplier, eqBoost2k4k y exciterLowOnly de forma coherente con la señal.
 */
JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetAntiDolbyScoresJni(
    JNIEnv* /*env*/, jclass /*clazz*/,
    jfloat speech, jfloat music, jfloat bass
) {
    if (!std::isfinite(speech) || !std::isfinite(music) || !std::isfinite(bass)) {
        LOGE("nativeSetAntiDolbyScoresJni: NaN/Inf ignorado");
        return;
    }
    const float s = std::clamp((float)speech, 0.0f, 1.0f);
    const float m = std::clamp((float)music,  0.0f, 1.0f);
    const float b = std::clamp((float)bass,   0.0f, 1.0f);

    // FIX crítico: reenviar al orquestador (antes se descartaba tras un LOGI)
    ivanna_set_anti_dolby_scores(s, m, b);
}

/**
 * Toggle Anti-Dolby desde la UI (MainActivity). Activa/desactiva el modo
 * en el orquestador C++. Cuando está desactivado, gState.antiDolby queda
 * en valores neutros (widenerMultiplier=1.0, eqBoost2k4k=0.0).
 */
JNIEXPORT void JNICALL
Java_com_ivanna_omega_audio_AudioEngine_nativeSetAntiDolbyEnabledJni(
    JNIEnv* /*env*/, jclass /*clazz*/,
    jboolean enabled
) {
    ivanna_set_anti_dolby_enabled(enabled ? 1 : 0);
    LOGI("Anti-Dolby modo: %s", enabled ? "ON" : "OFF");
}

} // extern "C"
