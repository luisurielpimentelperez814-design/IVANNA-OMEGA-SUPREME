# IVANNA-OMEGA-SUPREME — Fixes de Conectividad v1.6

## 🔴 v1.6 — Cableado real del Anti-Dolby (esta entrega)

Los fixes v1.5 dejaron el **canal de comunicación** listo (broadcast, permisos, JNI,
foreground service), pero el **efecto Anti-Dolby en sí** seguía sin conectar. Esta
revisión arregla los cinco eslabones rotos que quedaban:

---

### 🔴 FIX A1: `ivanna_jni_stub.cpp` — sólo hacía `LOGI`

**Problema:** La ruta estática `AudioPipeline.classifyAndRoute()` →
`AudioEngine.Companion.nativeSetAntiDolbyScoresStatic()` →
`nativeSetAntiDolbyScoresJni()` llegaba al stub JNI y **sólo se logueaba**. Los
scores YAMNet nunca alcanzaban `gState.antiDolby` — es decir, el clasificador
existía, corría, era llamado, y aun así el orquestador C++ no recibía nada.

**Fix:** El stub ahora reenvía a `ivanna_set_anti_dolby_scores()`
(símbolo `extern "C"` del orquestador). Añadido también
`ivanna_set_anti_dolby_enabled()` para el toggle de UI.

---

### 🔴 FIX A2: `audio_orchestrator.cpp` — Anti-Dolby leído pero no aplicado

**Problema:** `gState.antiDolby.widenerMultiplier` y `.eqBoost2k4k` se cargaban
en variables locales del bucle estéreo… y no se usaban. El comentario del código
mismo lo confesaba: `// Aplicar width reducido si es necesario (placeholder para
StereoWidener)`. El compresor Anti-Dolby, la EQ inversa Dolby, el exciter de
armónicos pares — nada de eso corría.

**Fix:** Reescrito el bloque de procesamiento estéreo con cableado real:

- **Widener M/S**: `L = mid + side * widthMul`, `R = mid - side * widthMul`
  (reduce imagen estéreo al 70 % cuando se detecta voz).
- **EQ 2-4 kHz**: biquad peaking RBJ (f₀ = 3 kHz, Q = 1.4), coeffs recalculadas
  sólo cuando cambia el gain para no consumir CPU.
- **Exciter armónico par**: `sign(x)·x²` con LPF one-pole opcional
  a ~120 Hz cuando `exciterLowOnly = true` (bass content detectado).
- **Flag global** `gState.antiDolbyEnabled` que neutraliza todos los ajustes
  cuando el usuario apaga el toggle (widthMul = 1, eqBoostDb = 0).

---

### 🔴 FIX A3: `AudioEngine.kt` — sin API para el toggle UI

**Problema:** El toggle Anti-Dolby de `MainActivity` sólo llamaba a
`IvannaGlobalEffectManager.applyProfile(SPATIAL)` (efectos de sistema:
Equalizer, BassBoost, Virtualizer). No existía forma de decirle al
**orquestador nativo** que activara el modo Anti-Dolby real.

**Fix:** Añadido `nativeSetAntiDolbyEnabledStatic(enabled)` en el companion object,
que enlaza con `nativeSetAntiDolbyEnabledJni` (`@JvmStatic`) implementado en
`ivanna_jni_stub.cpp`.

---

### 🔴 FIX A4: `MainActivity.kt` — toggle nunca tocaba el nativo

**Problema:** El toggle sólo aplicaba un `IvannaEffectProfile` global. El estado
`gState.antiDolby` del orquestador quedaba en `false` para siempre.

**Fix:**

1. El callback `onAntiDolbyChange` ahora llama
   `AudioEngine.nativeSetAntiDolbyEnabledStatic(enabled)`.
2. Al desactivar Anti-Dolby ya no se fuerza `FLAT`: se restaura el preset
   que el usuario tenía seleccionado (Warm, Rock 70s, etc.).
3. `initAudioEngine()` restaura el flag Anti-Dolby persistido al arrancar,
   coherente con lo que ve la UI. Antes el `Switch` marcaba `ON` visualmente
   pero el nativo estaba `OFF` tras un reinicio.

---

### 🔴 FIX A5: `AudioPipeline.kt` — clasificador roto por dos motivos

**Problema 1 (bug de estado):** `feedYamnet` guardaba `pos` en una variable
local y la reiniciaba a `yamnetWritePos = pos` sólo al salir. Con bloques de
256 frames estéreo, cada llamada aportaba ~43 muestras al ring de 15 600.
El `if (pos >= 15600)` nunca era cierto en una sola llamada, así que
`classifyAndRoute` casi nunca corría.

**Problema 2 (algoritmo incorrecto):** El clasificador usaba
`(frame[i] - frame[i-1]).abs()` como si fuera un proxy de frecuencia. Es un
proxy de derivada (energía en agudos), pero no permite discriminar bandas
correctamente. `bass`, `mid` y `high` quedaban muy correlacionados con la
propia amplitud instantánea.

**Fix:**

1. `yamnetWritePos` ahora **persiste** entre llamadas — se acumula muestra a
   muestra hasta llenar el ring. También se promedia L+R antes del downsample
   para no perder el canal derecho.
2. Clasificador reescrito con tres one-pole filters (LPF 250 Hz → bass,
   BPF 250 Hz-3 kHz → mid, HPF 3 kHz → high) más zero-crossing rate para
   distinguir voz vs música. Los scores enviados al orquestador son ahora
   representativos del contenido espectral real.

---

## 🔗 Diagrama de flujo v1.6 — Anti-Dolby cableado punto a punto

```
                    ┌──────────────────────────────────────────┐
                    │                MainActivity              │
                    │  toggle Anti-Dolby (Switch UI)           │
                    └───────────────────┬──────────────────────┘
                                        │  onAntiDolbyChange(enabled)
                    ┌───────────────────┼───────────────────────┐
                    ▼                                           ▼
   parameterStore.setAntiDolbyEnabled()     AudioEngine.nativeSetAntiDolbyEnabledStatic()
                                                   │
                                                   ▼
                                    ivanna_jni_stub.cpp
                                    nativeSetAntiDolbyEnabledJni()
                                                   │
                                                   ▼
                              audio_orchestrator.cpp
                              ivanna_set_anti_dolby_enabled()
                                                   │
                                                   ▼
                              gState.antiDolbyEnabled.store(on)


 AudioForegroundService.onCreate()
     └─► DSPBridge.init(48000)
         AudioPipeline.start()
             └─► loop 48 kHz stereo (256 frames/bloque)
                 ├─► DSPBridge.process(buf)   ← hot-path
                 ├─► feedYamnet(buf, read)    ← cada ~1 s
                 │       └─► ring 48→16 kHz mono (persistente)
                 │           └─► classifyAndRoute(frame)
                 │               ├─► LPF/BPF/HPF + ZCR
                 │               └─► AudioEngine.nativeSetAntiDolbyScoresStatic(s,m,b)
                 │                   └─► ivanna_jni_stub.cpp
                 │                       └─► ivanna_set_anti_dolby_scores(s,m,b)
                 │                           └─► gState.antiDolby.updateFromClassification()
                 │                               ├─► widenerMultiplier   (0.7 si speech)
                 │                               ├─► eqBoost2k4k         (+2 dB si speech)
                 │                               └─► exciterLowOnly      (true si bass)
                 └─► track.write(buf)         ← salida

    ┌─────── Java_..._nativeProcessAudio (hot-path DSP) ────────────┐
    │  IF gState.antiDolbyEnabled:                                  │
    │    widthMul  = antiDolby.widenerMultiplier                    │
    │    eqBoostDb = antiDolby.eqBoost2k4k                          │
    │    exciterLo = antiDolby.exciterLowOnly                       │
    │  ELSE:                                                        │
    │    widthMul=1, eqBoostDb=0, exciterLo=false                   │
    │                                                               │
    │  for each stereo frame:                                       │
    │    mid = (L+R)/2 ; side = (L-R)/2 * widthMul                  │
    │    L = mid+side ; R = mid-side                                │
    │    IF eqBoostDb != 0: biquad peaking 2-4 kHz on L and R       │
    │    IF exciterAmount > 0: sign(x)*x² [+ LPF 120 Hz si lowOnly] │
    │    limiter -0.1 dBFS hard-clip                                │
    └───────────────────────────────────────────────────────────────┘
```

Cinco eslabones que antes eran texto muerto (`AntiDolbyPreset.kt` no usado por
nadie, `nativeSetAntiDolbyScoresJni` que sólo logueaba, bucle estéreo con
`// placeholder`, toggle desconectado del nativo, ring buffer que nunca se
llenaba) ahora forman un circuito cerrado real desde el broadcast de Android
hasta la salida del `AudioTrack`.

---

## 🔧 v1.5 — Fixes de canal de comunicación (heredados)

Ver secciones anteriores en el historial del repositorio para los fixes 1-8
de v1.5 (AudioSessionReceiver, Manifest, IVANNAApplication, permisos runtime,
DSPBridge init tardío, OmegaEngineBridge socket reconnect, etc.).
