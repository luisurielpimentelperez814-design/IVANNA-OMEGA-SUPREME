#!/system/bin/sh
##########################################################################################
# IVANNA OMEGA SUPREME — customize.sh  (v1.9)
#
# Fixes vs v1.8:
#   [C1] SKU base blair venia con 8 duplicados de omega_effect -> corregido en vendor_base
#   [C2] append_music_apply_once ya no crea <postprocess> duplicado si postprocess existe
#        sin stream music: ahora inserta el stream DENTRO del postprocess existente.
#   [C3] El overlay se escribe SOLO en la ruta que realmente lee tu vendor (no se
#        contamina /system/etc si el vendor real vive en /vendor/etc, y viceversa).
#   [m1] .safe_mode se resetea al reinstalar (arranque limpio).
#   [m2] count_matches devuelve un unico entero (usa printf, no echo || echo 0).
##########################################################################################

SKIPUNZIP=0

count_matches() {
  # Cuenta ocurrencias exactas de un patron literal. Siempre devuelve un entero puro.
  pattern="$1"
  file="$2"
  n=$(grep -cF -- "$pattern" "$file" 2>/dev/null)
  [ -z "$n" ] && n=0
  printf '%s' "$n"
}

append_library_once() {
  in_file="$1"; out_file="$2"
  if grep -qF '<library name="omega_effect"' "$in_file" 2>/dev/null; then
    cp "$in_file" "$out_file"
  else
    sed 's#</libraries>#    <library name="omega_effect" path="libomega_effect.so"/>\n</libraries>#' "$in_file" > "$out_file"
  fi
}

append_effect_once() {
  in_file="$1"; out_file="$2"
  if grep -qF '<effect name="omega_effect"' "$in_file" 2>/dev/null; then
    cp "$in_file" "$out_file"
  else
    sed 's#</effects>#    <effect name="omega_effect" library="omega_effect" uuid="8d7d5e0a-a6eb-4fde-a0ff-cb1b2dd7275e" priority="1000"/>\n</effects>#' "$in_file" > "$out_file"
  fi
}

# [C2] insercion segura de <apply effect="omega_effect"/> en <stream type="music">
append_music_apply_once() {
  in_file="$1"; out_file="$2"

  if grep -qF '<stream type="music">' "$in_file" 2>/dev/null; then
    # Ya existe stream music: solo agrego el apply si no esta.
    awk '
      BEGIN { in_music = 0; has_apply = 0 }
      {
        if ($0 ~ /<stream type="music">/) { in_music = 1; has_apply = 0; print; next }
        if (in_music && $0 ~ /<apply effect="omega_effect"\/>/) { has_apply = 1; print; next }
        if (in_music && $0 ~ /<\/stream>/) {
          if (!has_apply) print "            <apply effect=\"omega_effect\"/>"
          in_music = 0; print; next
        }
        print
      }
    ' "$in_file" > "$out_file"
    return
  fi

  if grep -qF '<postprocess>' "$in_file" 2>/dev/null; then
    # Existe <postprocess> pero sin stream music: insertar stream DENTRO del bloque
    # existente (antes de </postprocess>). NUNCA crear un segundo <postprocess>.
    awk '
      {
        if ($0 ~ /<\/postprocess>/) {
          print "        <stream type=\"music\">"
          print "            <apply effect=\"omega_effect\"/>"
          print "        </stream>"
        }
        print
      }
    ' "$in_file" > "$out_file"
    return
  fi

  # No hay postprocess en absoluto: crear el bloque completo antes del cierre raiz.
  sed 's#</audio_effects_conf>#    <postprocess>\n        <stream type="music">\n            <apply effect="omega_effect"/>\n        </stream>\n    </postprocess>\n</audio_effects_conf>#' "$in_file" > "$out_file"
}

ui_print " "
ui_print "==============================================="
ui_print "   IVANNA OMEGA SUPREME v1.9"
ui_print "   (c) 2026 Luis Uriel Pimentel Perez"
ui_print "   Motor de audio neuromorfico (Anti-Dolby)"
ui_print "==============================================="
ui_print " "
ui_print "- Comprobando entorno..."
ui_print "  Magisk : $MAGISK_VER_CODE"
ui_print "  API    : $API"
ui_print "  ABI    : $ABI"

[ "$ABI" = "arm64-v8a" ] || abort "! Solo arm64-v8a (tu ABI: $ABI)"
[ "$API" -ge 28 ] || abort "! Requiere Android 9 (API 28) o superior. API actual: $API"

# [m1] limpia estado de instalaciones anteriores para partir de cero
rm -f "$MODPATH/.safe_mode"

# ---- 2. Verificacion de libomega_effect.so ---------------------------------
SO_REL="system/vendor/lib64/soundfx/libomega_effect.so"
SO_PATH="$MODPATH/$SO_REL"

ui_print "- Verificando libomega_effect.so..."
[ -f "$SO_PATH" ] || abort "! No se encontro $SO_REL en el ZIP. Modulo corrupto."

SO_SIZE=$(stat -c%s "$SO_PATH" 2>/dev/null || wc -c < "$SO_PATH")
ui_print "  Tamano: ${SO_SIZE} bytes"
[ "$SO_SIZE" -gt 0 ] || abort "! libomega_effect.so esta vacio"

MAGIC=$(dd if="$SO_PATH" bs=1 count=4 2>/dev/null | od -An -c | tr -d ' \n')
case "$MAGIC" in
  *ELF*) ui_print "  ELF header OK" ;;
  *)     abort "! libomega_effect.so no es un ELF valido" ;;
esac

if command -v strings >/dev/null 2>&1; then
  if strings "$SO_PATH" | grep -q "AUDIO_EFFECT_LIBRARY_INFO_SYM"; then
    ui_print "  Simbolo AUDIO_EFFECT_LIBRARY_INFO_SYM presente"
  else
    ui_print "! ADVERTENCIA: no se encuentra AUDIO_EFFECT_LIBRARY_INFO_SYM."
    ui_print "  El framework de audio NO cargara el efecto como postprocess."
    ui_print "  Activando MODO SEGURO (solo JNI, sin overlay XML)."
    touch "$MODPATH/.safe_mode"
  fi
fi

# ---- 3. Localizar audio_effects.xml REAL del vendor ------------------------
ui_print "- Localizando audio_effects.xml real..."

LIVE_XML=""
for CAND in /vendor/etc/audio_effects.xml /odm/etc/audio_effects.xml /system/etc/audio_effects.xml; do
  if [ -f "$CAND" ] && grep -q "<audio_effects_conf" "$CAND" 2>/dev/null; then
    LIVE_XML="$CAND"
    break
  fi
done

BASE_XML="$MODPATH/.base_audio_effects.xml"

if [ -n "$LIVE_XML" ]; then
  ui_print "  Encontrado: $LIVE_XML (base real)"
  cp "$LIVE_XML" "$BASE_XML"
else
  ui_print "! No se pudo leer XML del vendor. Usando referencia empaquetada."
  SKU_GUESS="holi"
  if getprop 2>/dev/null | grep -qi "dolby\|dap\|blair"; then
    SKU_GUESS="blair"
  fi
  ui_print "  SKU estimado: $SKU_GUESS"
  cp "$MODPATH/vendor_base/sku_${SKU_GUESS}_audio_effects.xml" "$BASE_XML" 2>/dev/null \
    || cp "$MODPATH/vendor_base/sku_holi_audio_effects.xml" "$BASE_XML"
fi

cp "$BASE_XML" "$MODPATH/audio_effects.xml.orig"

MERGED="$MODPATH/.merged_audio_effects.xml"
append_library_once   "$BASE_XML"   "${MERGED}.1"
append_effect_once    "${MERGED}.1" "${MERGED}.2"
append_music_apply_once "${MERGED}.2" "${MERGED}.3"

LIB_COUNT=$(count_matches '<library name="omega_effect"' "${MERGED}.3")
EFFECT_COUNT=$(count_matches '<effect name="omega_effect"' "${MERGED}.3")
APPLY_COUNT=$(count_matches '<apply effect="omega_effect"/>' "${MERGED}.3")
POST_COUNT=$(count_matches '<postprocess>' "${MERGED}.3")

grep -q '<audio_effects_conf' "${MERGED}.3" || abort "! XML fusionado invalido (falta <audio_effects_conf>)"
[ "$LIB_COUNT"   = "1" ] || abort "! Fusion insegura: library=$LIB_COUNT"
[ "$EFFECT_COUNT" = "1" ] || abort "! Fusion insegura: effect=$EFFECT_COUNT"
[ "$APPLY_COUNT" = "1" ] || abort "! Fusion insegura: apply=$APPLY_COUNT"
[ "$POST_COUNT"  = "1" ] || abort "! Fusion insegura: <postprocess> aparece $POST_COUNT veces"

# [C3] Escribir el overlay SOLO en la ruta que corresponde al vendor real,
#      para que Magisk enmascare exactamente el archivo activo y no meta
#      un XML basura en la otra ruta.
if [ "$LIVE_XML" = "/vendor/etc/audio_effects.xml" ] || [ -z "$LIVE_XML" ]; then
  OVERLAY_REL="system/vendor/etc/audio_effects.xml"
elif [ "$LIVE_XML" = "/system/etc/audio_effects.xml" ]; then
  OVERLAY_REL="system/etc/audio_effects.xml"
else
  # /odm/etc/... : Magisk no soporta /odm bien, montamos en /vendor/etc como best-effort
  OVERLAY_REL="system/vendor/etc/audio_effects.xml"
fi

mkdir -p "$MODPATH/$(dirname "$OVERLAY_REL")"
cp "${MERGED}.3" "$MODPATH/$OVERLAY_REL"
rm -f "${MERGED}.1" "${MERGED}.2" "${MERGED}.3" "$BASE_XML"

ui_print "  audio_effects.xml fusionado idempotente ->  /$OVERLAY_REL"
ui_print "  Backup del XML original: $MODPATH/audio_effects.xml.orig"

# ---- 4. Modo seguro: si .so no expone la fabrica, retiramos el overlay ----
if [ -f "$MODPATH/.safe_mode" ]; then
  ui_print "- MODO SEGURO activo: retirando overlay XML para no romper audioserver"
  rm -f "$MODPATH/$OVERLAY_REL"
  ui_print "  libomega_effect.so queda como libreria JNI (uso desde la app IVANNA)"
fi

# ---- 5. Permisos ----------------------------------------------------------
ui_print "- Ajustando permisos..."
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
set_perm           "$SO_PATH"        0 0 0644
[ -f "$MODPATH/$OVERLAY_REL" ] && set_perm "$MODPATH/$OVERLAY_REL" 0 0 0644

# ---- 6. Contexto SELinux --------------------------------------------------
if command -v chcon >/dev/null 2>&1; then
  chcon u:object_r:vendor_file:s0 "$SO_PATH" 2>/dev/null \
    && ui_print "  SELinux: $SO_REL -> u:object_r:vendor_file:s0"
fi

# ---- 7. Resumen -----------------------------------------------------------
ui_print " "
ui_print "==============================================="
if [ -f "$MODPATH/.safe_mode" ]; then
  ui_print "  Instalacion en MODO SEGURO."
  ui_print "  Recompila omega_effect.cpp exportando la"
  ui_print "  estructura audio_effect_library_t (create_effect,"
  ui_print "  release_effect, get_descriptor) para activar el"
  ui_print "  efecto global."
else
  ui_print "  Instalacion completada. Reinicia para activar."
  ui_print "  omega_effect fusionado en tu audio_effects.xml"
  ui_print "  real: bassboost/EQ/Dolby/AEC de llamadas intactos."
fi
ui_print "==============================================="
ui_print " "
