#!/system/bin/sh
# IVANNA OMEGA SUPREME v1.9 — service.sh
MODDIR=${0%/*}
LOG=/data/adb/ivanna_omega.log

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done

echo "[$(date '+%H:%M:%S')] service: boot_completed -> reset contador" >> "$LOG"
echo "0" > /data/adb/ivanna_omega_boot_counter

# Compatibilidad: pidof no existe en todas las ROMs. Fallback a ps.
AUDIO_PID=""
if command -v pidof >/dev/null 2>&1; then
  AUDIO_PID=$(pidof audioserver 2>/dev/null | awk '{print $1}')
fi
if [ -z "$AUDIO_PID" ]; then
  AUDIO_PID=$(ps -Ao pid,comm 2>/dev/null | awk '$2=="audioserver"{print $1; exit}')
fi
if [ -z "$AUDIO_PID" ]; then
  AUDIO_PID=$(ps 2>/dev/null | awk '/audioserver/ && !/awk/ {print $2; exit}')
fi

if [ -n "$AUDIO_PID" ]; then
  echo "[$(date '+%H:%M:%S')] service: audioserver activo pid=$AUDIO_PID" >> "$LOG"
else
  echo "[$(date '+%H:%M:%S')] service: WARN audioserver no detectado" >> "$LOG"
fi

if command -v dumpsys >/dev/null 2>&1; then
  dumpsys media.audio_policy 2>/dev/null | grep -A2 -i "omega\|dolby" >> "$LOG" 2>&1
fi
