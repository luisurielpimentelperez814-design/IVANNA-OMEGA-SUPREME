#!/system/bin/sh
# IVANNA OMEGA SUPREME v1.9 — post-fs-data.sh
# Anti-bootloop: si audioserver cae 3 veces seguidas antes de boot_completed,
# retiramos el overlay para no dejar el telefono sin audio.

MODDIR=${0%/*}
LOG=/data/adb/ivanna_omega.log
log() { echo "[$(date '+%H:%M:%S')] $1" >> "$LOG"; }

log "post-fs-data: iniciando"

COUNTER=/data/adb/ivanna_omega_boot_counter
COUNT=0
[ -f "$COUNTER" ] && COUNT=$(cat "$COUNTER" 2>/dev/null)
case "$COUNT" in ''|*[!0-9]*) COUNT=0 ;; esac
COUNT=$((COUNT + 1))
echo "$COUNT" > "$COUNTER"
log "post-fs-data: boot #$COUNT desde ultima instalacion"

if [ "$COUNT" -ge 3 ] && [ ! -f "$MODDIR/.safe_mode" ]; then
  log "post-fs-data: 3+ boots seguidos -> MODO SEGURO"
  touch "$MODDIR/.safe_mode"
  rm -f "$MODDIR/system/vendor/etc/audio_effects.xml" \
        "$MODDIR/system/etc/audio_effects.xml"
fi

log "post-fs-data: OK"
