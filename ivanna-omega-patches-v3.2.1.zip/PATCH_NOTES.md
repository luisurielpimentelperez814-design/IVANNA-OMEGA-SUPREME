# IVANNA OMEGA — Patch v3.2.1 (fix build)

## Problema detectado en los logs de GitHub Actions
Build APK falla con:

```
e: PlaybackCaptureService.kt:434:55 Unresolved reference: resample
```

Los tests nativos DSP (CTest) y el resto del pipeline pasan. Solo Kotlin rompe.

## Causa
`PlaybackCaptureService` invoca `buffer.resample(inRate, outRate, channels)`
pero no existía ninguna declaración `resample` importable en el classpath.

## Solución (regla de oro: no borrar, añadir)
Se añade el fichero:

- `app/src/main/java/com/ivanna/omega/audio/AudioResample.kt`

Con dos extensiones en el mismo package que el servicio
(`com.ivanna.omega.audio`), por lo que **no requiere import** desde
`PlaybackCaptureService.kt`:

- `FloatArray.resample(inRate: Int, outRate: Int, channels: Int = 1): FloatArray`
- `ShortArray.resample(inRate: Int, outRate: Int, channels: Int = 1): ShortArray`

Interpolación lineal, mono/multicanal intercalado, con guardas para
tasas iguales, tamaños degenerados y sample-rate <= 0.

## Instalación
Descomprime sobre la raíz del repo Android. No toca `build.gradle`, no
requiere sync. Rebuild y `:app:compileDebugKotlin` debe pasar.

## Si la llamada no encaja
Si la línea 434 llama con otra firma (p. ej. `resample(outRate)` sin canales),
ajusta la llamada — no borres estas extensiones; añadirán compatibilidad.
