package com.ivanna.omega.audio

/**
 * IVANNA OMEGA — Audio resample helpers (v3.2.1)
 *
 * Regla de oro: no borramos, añadimos.
 * Aporta la extensión `resample(...)` que PlaybackCaptureService.kt:434 esperaba
 * y que no estaba declarada en ningún módulo del proyecto (unresolved reference).
 *
 * Implementación: interpolación lineal en punto flotante, mono o multi-canal
 * intercalado, con protección frente a tasas iguales, entrada vacía y
 * sample-rates <= 0. Suficiente para PCM capturado y ligera para el hilo de
 * audio; si más adelante quieres sinc/polifase, esta función queda como
 * fallback y bastará con delegar aquí.
 */

/** Resamplea PCM float intercalado de [inRate] Hz a [outRate] Hz. */
fun FloatArray.resample(inRate: Int, outRate: Int, channels: Int = 1): FloatArray {
    require(channels >= 1) { "channels must be >= 1" }
    if (isEmpty() || inRate <= 0 || outRate <= 0 || inRate == outRate) return this

    val frames = size / channels
    if (frames < 2) return this

    val ratio = outRate.toDouble() / inRate.toDouble()
    val outFrames = (frames * ratio).toInt().coerceAtLeast(1)
    val out = FloatArray(outFrames * channels)
    val step = (frames - 1).toDouble() / (outFrames - 1).coerceAtLeast(1)

    var pos = 0.0
    for (i in 0 until outFrames) {
        val idx = pos.toInt().coerceIn(0, frames - 1)
        val next = (idx + 1).coerceAtMost(frames - 1)
        val frac = (pos - idx).toFloat()
        val base = i * channels
        val a = idx * channels
        val b = next * channels
        for (c in 0 until channels) {
            val s0 = this[a + c]
            val s1 = this[b + c]
            out[base + c] = s0 + (s1 - s0) * frac
        }
        pos += step
    }
    return out
}

/** Variante Short (PCM 16) — mismo contrato, útil si la llamada usa ShortArray. */
fun ShortArray.resample(inRate: Int, outRate: Int, channels: Int = 1): ShortArray {
    if (isEmpty() || inRate <= 0 || outRate <= 0 || inRate == outRate) return this
    val asFloat = FloatArray(size) { this[it] / 32768f }
    val res = asFloat.resample(inRate, outRate, channels)
    return ShortArray(res.size) { (res[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
}
