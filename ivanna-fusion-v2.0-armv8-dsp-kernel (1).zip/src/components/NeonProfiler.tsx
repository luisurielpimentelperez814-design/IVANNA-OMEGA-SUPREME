import React from 'react';
import { BenchmarkMetrics } from '../types';
import { Cpu, Zap, ShieldCheck, CheckCircle2, HardDrive, Terminal } from 'lucide-react';

interface NeonProfilerProps {
  metrics: BenchmarkMetrics;
}

export const NeonProfiler: React.FC<NeonProfilerProps> = ({ metrics }) => {
  return (
    <div className="space-y-6 font-mono">
      
      {/* Metrics Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="text-xs text-slate-400">1024-FRAME LATENCY</div>
          <div className="text-xl font-bold text-cyan-400">
            {metrics.blockLatencyMicroseconds.toFixed(1)} µs
          </div>
          <div className="text-[10px] text-emerald-400">
            {(metrics.sampleLatencyNanoseconds).toFixed(1)} ns / sample
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="text-xs text-slate-400">SIMD VECTORIZATION</div>
          <div className="text-xl font-bold text-emerald-400">
            {metrics.simdEfficiencyPercent}% NEON
          </div>
          <div className="text-[10px] text-slate-400">
            128-bit float32x4_t / int16x8_t
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="text-xs text-slate-400">AUDIO THREAD HEAP</div>
          <div className="text-xl font-bold text-emerald-400 flex items-center gap-1.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            0 Bytes
          </div>
          <div className="text-[10px] text-slate-400">
            Zero heap allocations in process()
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="text-xs text-slate-400">L1 CACHE HIT RATE</div>
          <div className="text-xl font-bold text-amber-400">
            {metrics.l1CacheHitRatePercent}%
          </div>
          <div className="text-[10px] text-slate-400">
            alignas(16) cacheline fit
          </div>
        </div>

      </div>

      {/* Assembly & Intrinsics Map */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Compiler & Target Architecture Specs */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            ARMv8 Target Flags & Compiler Optimizations
          </h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Target CPU & Architecture:</span>
              <span className="text-cyan-300 font-bold">-mcpu=cortex-a76 -march=armv8.2-a+simd+fp16</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Optimization Level:</span>
              <span className="text-emerald-400 font-bold">-O3 -ffast-math -ftree-vectorize</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Link Time Optimization (LTO):</span>
              <span className="text-emerald-400 font-bold">-flto</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Exception & RTTI Overhead:</span>
              <span className="text-amber-400 font-bold">-fno-exceptions -fno-rtti</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Frame Pointer & Alignment:</span>
              <span className="text-slate-200">-fomit-frame-pointer alignas(16)</span>
            </div>
          </div>
        </div>

        {/* NEON Intrinsics Breakdown */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-amber-400" />
            Core ARM NEON Intrinsics & Instructions Used
          </h3>
          <div className="space-y-2 text-xs">
            <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
              <div>
                <code className="text-cyan-300 font-bold">vmlaq_f32(a, b, c)</code>
                <span className="block text-[10px] text-slate-400">Vector Fused Multiply-Add (a + b * c)</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px]">
                FIR & HRTF Loops
              </span>
            </div>

            <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
              <div>
                <code className="text-emerald-300 font-bold">vrecpeq_f32 / vrecpsq_f32</code>
                <span className="block text-[10px] text-slate-400">Reciprocal estimate & Newton-Raphson step</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px]">
                fast_tanh_neon
              </span>
            </div>

            <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
              <div>
                <code className="text-amber-300 font-bold">vld1q_f32 / vst1q_f32</code>
                <span className="block text-[10px] text-slate-400">128-bit aligned vector load & store</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px]">
                alignas(16) Buffers
              </span>
            </div>

            <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
              <div>
                <code className="text-purple-300 font-bold">vdupq_n_s16 / vmulq_s16</code>
                <span className="block text-[10px] text-slate-400">Quantized int16 vector multiply</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px]">
                TinyML LSTM int8
              </span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
