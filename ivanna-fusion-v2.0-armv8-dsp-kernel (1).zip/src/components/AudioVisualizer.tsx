import React, { useEffect, useRef, useState } from 'react';
import { DspParameters } from '../types';
import { Play, Pause, Volume2, VolumeX, Radio, Sparkles, Activity } from 'lucide-react';

interface AudioVisualizerProps {
  params: DspParameters;
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ params }) => {
  const oscCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const specCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [signalType, setSignalType] = useState<'sine' | 'impulse' | 'harmonics' | 'noise'>('harmonics');
  const [fundamentalFreq, setFundamentalFreq] = useState(440);

  // Web Audio Context & Oscillator setup for audio preview
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscNodeRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  const toggleAudio = () => {
    if (isPlaying) {
      if (audioCtxRef.current) {
        audioCtxRef.current.suspend();
      }
      setIsPlaying(false);
    } else {
      if (!audioCtxRef.current) {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AudioCtx();
        const gain = ctx.createGain();
        gain.gain.value = 0.15;
        gain.connect(ctx.destination);

        const osc = ctx.createOscillator();
        osc.type = signalType === 'sine' ? 'sine' : signalType === 'noise' ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(fundamentalFreq, ctx.currentTime);
        osc.connect(gain);
        osc.start();

        audioCtxRef.current = ctx;
        oscNodeRef.current = osc;
        gainNodeRef.current = gain;
      } else {
        audioCtxRef.current.resume();
      }
      setIsPlaying(true);
    }
  };

  useEffect(() => {
    if (oscNodeRef.current && audioCtxRef.current) {
      oscNodeRef.current.frequency.setValueAtTime(fundamentalFreq, audioCtxRef.current.currentTime);
    }
  }, [fundamentalFreq]);

  // Canvas Oscilloscope & Spectrum Simulation Loop
  useEffect(() => {
    let animId: number;
    let phase = 0;

    const render = () => {
      phase += 0.08;

      // 1. Oscilloscope Render
      const oscCanvas = oscCanvasRef.current;
      if (oscCanvas) {
        const ctx = oscCanvas.getContext('2d');
        if (ctx) {
          const w = oscCanvas.width;
          const h = oscCanvas.height;

          ctx.fillStyle = '#020617';
          ctx.fillRect(0, 0, w, h);

          // Grid lines
          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(0, h / 2);
          ctx.lineTo(w, h / 2);
          ctx.stroke();

          // Raw Input Wave (Dimmed)
          ctx.strokeStyle = 'rgba(100, 116, 139, 0.4)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          for (let x = 0; x < w; x++) {
            const t = (x / w) * Math.PI * 8 + phase;
            let val = 0;
            if (signalType === 'sine') val = Math.sin(t);
            else if (signalType === 'harmonics') val = Math.sin(t) + 0.3 * Math.sin(2 * t) + 0.2 * Math.sin(3 * t);
            else if (signalType === 'impulse') val = (x % 60 === 0) ? 0.9 : 0;
            else val = (Math.random() - 0.5) * 1.5;

            const y = h / 2 - val * (h * 0.3);
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();

          // Processed Output Wave (IVANNA DSP Kernel)
          ctx.strokeStyle = params.goldenEarEnabled ? '#f59e0b' : '#06b6d4';
          ctx.lineWidth = 2.5;
          ctx.shadowBlur = 8;
          ctx.shadowColor = params.goldenEarEnabled ? '#f59e0b' : '#06b6d4';
          ctx.beginPath();

          for (let x = 0; x < w; x++) {
            const t = (x / w) * Math.PI * 8 + phase;
            let raw = 0;
            if (signalType === 'sine') raw = Math.sin(t);
            else if (signalType === 'harmonics') raw = Math.sin(t) + 0.3 * Math.sin(2 * t) + 0.2 * Math.sin(3 * t);
            else if (signalType === 'impulse') raw = (x % 60 === 0) ? 0.9 : 0;
            else raw = (Math.random() - 0.5) * 1.5;

            // Apply fatigue damping
            let out = raw * params.iirAlpha;

            // Apply Golden Ear Chebyshev harmonics
            if (params.goldenEarEnabled) {
              const drv = out * params.goldenEarDrive;
              const h2 = 2.0 * (drv * drv) - 1.0;
              const h3 = 4.0 * (drv * drv * drv) - 3.0 * drv;
              out = out + (h2 * 0.12 + h3 * 0.08) * params.goldenEarMix;
              // Soft tanh clip
              out = Math.tanh(out);
            }

            const y = h / 2 - out * (h * 0.32);
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
          ctx.shadowBlur = 0;
        }
      }

      // 2. Spectrum Analyzer Render
      const specCanvas = specCanvasRef.current;
      if (specCanvas) {
        const ctx = specCanvas.getContext('2d');
        if (ctx) {
          const w = specCanvas.width;
          const h = specCanvas.height;

          ctx.fillStyle = '#020617';
          ctx.fillRect(0, 0, w, h);

          const bars = 64;
          const barWidth = w / bars;

          for (let i = 0; i < bars; i++) {
            const freqRatio = i / bars;
            let magnitude = Math.exp(-freqRatio * 3) * (0.6 + 0.4 * Math.sin(phase * 2 + i * 0.3));

            // High frequency roll-off due to fatigue IIR
            if (i > 30) {
              magnitude *= params.iirAlpha;
            }

            // Harmonic peaks if Golden Ear is active
            if (params.goldenEarEnabled && (i % 8 === 0 || i % 12 === 0)) {
              magnitude += 0.25 * params.goldenEarMix;
            }

            const barHeight = Math.min(h * 0.85, magnitude * h);

            const gradient = ctx.createLinearGradient(0, h, 0, h - barHeight);
            if (params.goldenEarEnabled) {
              gradient.addColorStop(0, '#78350f');
              gradient.addColorStop(0.5, '#f59e0b');
              gradient.addColorStop(1, '#fef08a');
            } else {
              gradient.addColorStop(0, '#0e7490');
              gradient.addColorStop(0.5, '#06b6d4');
              gradient.addColorStop(1, '#a5f3fc');
            }

            ctx.fillStyle = gradient;
            ctx.fillRect(i * barWidth, h - barHeight, barWidth - 2, barHeight);
          }
        }
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [params, signalType]);

  return (
    <div className="space-y-6">
      
      {/* Controls Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 backdrop-blur flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Signal Selector */}
        <div className="flex items-center space-x-2 overflow-x-auto font-mono text-xs">
          <span className="text-slate-400 font-bold mr-2">Signal Input:</span>
          {(['harmonics', 'sine', 'impulse', 'noise'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setSignalType(type)}
              className={`px-3 py-1.5 rounded-lg border uppercase transition-all ${
                signalType === type
                  ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300 font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Fundamental Freq Slider & Audio Toggle */}
        <div className="flex items-center space-x-4 font-mono text-xs">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">Fundamental:</span>
            <input
              type="range"
              min="100"
              max="2000"
              step="10"
              value={fundamentalFreq}
              onChange={(e) => setFundamentalFreq(Number(e.target.value))}
              className="w-28 accent-cyan-400 bg-slate-950 rounded"
            />
            <span className="text-cyan-400 font-bold w-12">{fundamentalFreq}Hz</span>
          </div>

          <button
            onClick={toggleAudio}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-bold transition-all shadow-md ${
              isPlaying
                ? 'bg-rose-500/20 border border-rose-500/40 text-rose-300 shadow-rose-950/50'
                : 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 shadow-emerald-950/50'
            }`}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isPlaying ? 'MUTE AUDIO' : 'PLAY SENSE'}</span>
          </button>
        </div>

      </div>

      {/* Visualizers Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Oscilloscope */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between font-mono text-xs">
            <div className="flex items-center space-x-2 text-slate-200 font-bold">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>1024-Sample Time-Domain Oscilloscope</span>
            </div>
            <div className="flex items-center space-x-3 text-[11px]">
              <span className="flex items-center gap-1 text-slate-400">
                <span className="w-2.5 h-0.5 bg-slate-500 inline-block"></span> Raw Input
              </span>
              <span className="flex items-center gap-1 text-cyan-400 font-bold">
                <span className={`w-2.5 h-0.5 inline-block ${params.goldenEarEnabled ? 'bg-amber-400' : 'bg-cyan-400'}`}></span> IVANNA DSP
              </span>
            </div>
          </div>
          <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
            <canvas
              ref={oscCanvasRef}
              width={600}
              height={260}
              className="w-full h-56 object-cover"
            />
          </div>
        </div>

        {/* Spectrum Analyzer */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between font-mono text-xs">
            <div className="flex items-center space-x-2 text-slate-200 font-bold">
              <Radio className="w-4 h-4 text-emerald-400" />
              <span>Real-time 64-Band FFT Spectral Density</span>
            </div>
            <div className="text-xs font-mono text-slate-400">
              0 Hz — 24,000 Hz
            </div>
          </div>
          <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
            <canvas
              ref={specCanvasRef}
              width={600}
              height={260}
              className="w-full h-56 object-cover"
            />
          </div>
        </div>

      </div>

    </div>
  );
};
