import React from 'react';
import { Cpu, Zap, Activity, ShieldCheck, Terminal } from 'lucide-react';

interface HeaderProps {
  activeTab: 'pipeline' | 'visualizer' | 'benchmarks' | 'code' | 'termux';
  setActiveTab: (tab: 'pipeline' | 'visualizer' | 'benchmarks' | 'code' | 'termux') => void;
  goldenEarEnabled: boolean;
  onToggleGoldenEar: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  goldenEarEnabled,
  onToggleGoldenEar,
}) => {
  return (
    <header id="header-container" className="border-b border-cyan-900/50 bg-slate-950/80 backdrop-blur sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Logo & Status */}
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-cyan-500/20 to-emerald-500/10 border border-cyan-500/30 text-cyan-400 shadow-lg shadow-cyan-950/50">
              <Cpu className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-bold tracking-wider text-slate-100 font-mono">
                  IVANNA-FUSION <span className="text-cyan-400">v2.0</span>
                </h1>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-mono font-semibold">
                  ARMv8 NEON
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 font-mono">
                  0-Alloc
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Native C++17 Audio Kernel & TinyML Engine • Termux Android Magisk Daemon
              </p>
            </div>
          </div>

          {/* Quick Controls & Status Badges */}
          <div className="flex items-center space-x-3 overflow-x-auto pb-1 md:pb-0">
            <button
              id="golden-ear-toggle-btn"
              onClick={onToggleGoldenEar}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border font-mono text-xs font-semibold transition-all shadow-sm ${
                goldenEarEnabled
                  ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 shadow-amber-950/50'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Zap className={`w-3.5 h-3.5 ${goldenEarEnabled ? 'text-amber-400 animate-spin-slow' : ''}`} />
              <span>Golden Ear GAN: {goldenEarEnabled ? 'ACTIVE' : 'OFF'}</span>
            </button>

            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800 font-mono text-xs text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Heap Alloc: <strong className="text-emerald-400">0 Bytes</strong></span>
            </div>
          </div>

        </div>

        {/* Navigation Tabs */}
        <nav id="header-nav-tabs" className="flex space-x-1 mt-4 overflow-x-auto border-t border-slate-800/80 pt-2 font-mono text-xs">
          <button
            id="tab-pipeline-btn"
            onClick={() => setActiveTab('pipeline')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'pipeline'
                ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>DSP Pipeline Topology</span>
          </button>

          <button
            id="tab-visualizer-btn"
            onClick={() => setActiveTab('visualizer')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'visualizer'
                ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>Audio & Spectrum Simulator</span>
          </button>

          <button
            id="tab-benchmarks-btn"
            onClick={() => setActiveTab('benchmarks')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'benchmarks'
                ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>ARMv8 NEON Benchmark</span>
          </button>

          <button
            id="tab-code-btn"
            onClick={() => setActiveTab('code')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'code'
                ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>C++ Source Files & CMake</span>
          </button>

          <button
            id="tab-termux-btn"
            onClick={() => setActiveTab('termux')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'termux'
                ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Terminal className="w-4 h-4 text-amber-400" />
            <span>Termux 1-Click Installer</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
