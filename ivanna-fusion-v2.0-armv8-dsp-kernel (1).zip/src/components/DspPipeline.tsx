import React from 'react';
import { DspParameters } from '../types';
import { Cpu, Zap, Activity, Waves, Sliders, ShieldAlert, Sparkles, ArrowRight } from 'lucide-react';

interface DspPipelineProps {
  params: DspParameters;
  onParamChange: (key: keyof DspParameters, value: number | boolean) => void;
}

export const DspPipeline: React.FC<DspPipelineProps> = ({ params, onParamChange }) => {
  return (
    <div className="space-y-6">
      
      {/* Intro Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 backdrop-blur">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100 font-mono flex items-center gap-2">
              <Activity className="w-5 h-5 text-cyan-400" />
              IVANNA-FUSION v2.0 - Signal Processing Pipeline Architecture
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-3xl">
              100% ARMv8 NEON vectorization (`float32x4_t`, `int16x8_t`). Designed for zero heap allocations in the audio thread, sub-microsecond latency, L1 cache optimization, and phase-lock stability.
            </p>
          </div>
          <div className="flex items-center gap-3 font-mono text-xs">
            <div className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-slate-400 block text-[10px]">SAMPLE RATE</span>
              <span className="text-cyan-400 font-bold">48,000 Hz</span>
            </div>
            <div className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-slate-400 block text-[10px]">BLOCK SIZE</span>
              <span className="text-emerald-400 font-bold">1024 frames</span>
            </div>
            <div className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-slate-400 block text-[10px]">ALIGNMENT</span>
              <span className="text-amber-400 font-bold">alignas(16)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Nodes Interactive Diagram */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* Node 1: TinyML LSTM Fatigue Predictor */}
        <div className="bg-slate-900/80 border border-cyan-500/30 rounded-2xl p-5 space-y-3 relative group hover:border-cyan-400/60 transition-all shadow-lg shadow-cyan-950/20">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              STAGE 01
            </span>
            <ShieldAlert className="w-4 h-4 text-cyan-400" />
          </div>
          <h3 className="text-sm font-bold font-mono text-slate-100 flex items-center gap-1.5">
            TinyML int8 LSTM
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Quantized 8-unit LSTM inference in Q.7/Q.8 fixed-point evaluating RMS accumulation to predict listening fatigue.
          </p>
          <div className="pt-2 border-t border-slate-800/80 font-mono text-xs space-y-1.5">
            <div className="flex justify-between text-slate-400">
              <span>Fatigue Index:</span>
              <span className="text-cyan-300 font-bold">{(params.fatigueIndex * 100).toFixed(0)}%</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
              <div 
                className="bg-cyan-400 h-full transition-all duration-300"
                style={{ width: `${params.fatigueIndex * 100}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-400 pt-1">
              <span>Dynamic IIR Cut:</span>
              <span className="text-emerald-400 font-bold">Alpha {(params.iirAlpha).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Node 2: Evolutionary EQ */}
        <div className="bg-slate-900/80 border border-emerald-500/30 rounded-2xl p-5 space-y-3 relative group hover:border-emerald-400/60 transition-all shadow-lg shadow-emerald-950/20">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              STAGE 02
            </span>
            <Sliders className="w-4 h-4 text-emerald-400" />
          </div>
          <h3 className="text-sm font-bold font-mono text-slate-100 flex items-center gap-1.5">
            LM-CMA-ES FIR EQ
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            256-Tap time-domain FIR filter driven by 512-band evolutionary genome with phase-smoothness penalization constraint.
          </p>
          <div className="pt-2 border-t border-slate-800/80 font-mono text-xs space-y-1.5">
            <div className="flex justify-between text-slate-400">
              <span>Taps / SIMD Unroll:</span>
              <span className="text-emerald-300 font-bold">256 / 4-Tap</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Genome Bands:</span>
              <span className="text-slate-200">512 Bands</span>
            </div>
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Evolution Step:</span>
              <span className="text-amber-400 font-bold">{params.eqMutationRate.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Node 3: Psychoacoustic Masking */}
        <div className="bg-slate-900/80 border border-purple-500/30 rounded-2xl p-5 space-y-3 relative group hover:border-purple-400/60 transition-all shadow-lg shadow-purple-950/20">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
              STAGE 03
            </span>
            <Waves className="w-4 h-4 text-purple-400" />
          </div>
          <h3 className="text-sm font-bold font-mono text-slate-100 flex items-center gap-1.5">
            Dynamic Masking
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Envelope follower-driven upward expander preventing transient crushing during high-energy bass peaks.
          </p>
          <div className="pt-2 border-t border-slate-800/80 font-mono text-xs space-y-1.5">
            <div className="flex justify-between text-slate-400">
              <span>Attack / Release:</span>
              <span className="text-purple-300 font-bold">1ms / 10ms</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Expander Ratio:</span>
              <span className="text-slate-200">1:1.5 Upward</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Threshold:</span>
              <span className="text-purple-400 font-bold">-40 dBFS</span>
            </div>
          </div>
        </div>

        {/* Node 4: 3D Binaural HRTF */}
        <div className="bg-slate-900/80 border border-blue-500/30 rounded-2xl p-5 space-y-3 relative group hover:border-blue-400/60 transition-all shadow-lg shadow-blue-950/20">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
              STAGE 04
            </span>
            <Cpu className="w-4 h-4 text-blue-400" />
          </div>
          <h3 className="text-sm font-bold font-mono text-slate-100 flex items-center gap-1.5">
            3D Binaural HRTF
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            2x2 crosstalk matrix convolution implementing Rayleigh spherical head model ITD and ILD spatial acoustic simulation.
          </p>
          <div className="pt-2 border-t border-slate-800/80 font-mono text-xs space-y-1.5">
            <div className="flex justify-between text-slate-400">
              <span>Crosstalk Gain:</span>
              <span className="text-blue-300 font-bold">{(params.crosstalkGain * 100).toFixed(0)}%</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>ITD Delay:</span>
              <span className="text-slate-200">{params.hrtfDelayMs.toFixed(1)} ms</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>HRTF Taps:</span>
              <span className="text-blue-400 font-bold">128 Taps</span>
            </div>
          </div>
        </div>

        {/* Node 5: Golden Ear GAN */}
        <div className={`bg-slate-900/80 border rounded-2xl p-5 space-y-3 relative group transition-all shadow-lg ${
          params.goldenEarEnabled
            ? 'border-amber-500/50 shadow-amber-950/30 hover:border-amber-400'
            : 'border-slate-800 opacity-75'
        }`}>
          <div className="flex items-center justify-between">
            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
              params.goldenEarEnabled
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}>
              STAGE 05
            </span>
            <Sparkles className={`w-4 h-4 ${params.goldenEarEnabled ? 'text-amber-400' : 'text-slate-500'}`} />
          </div>
          <h3 className="text-sm font-bold font-mono text-slate-100 flex items-center gap-1.5">
            Golden Ear GAN
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Chebyshev non-linear harmonic exciter H2(x)=2x^2-1 and H3(x)=4x^3-3x with Newton-Raphson fast_tanh_neon soft clipping.
          </p>
          <div className="pt-2 border-t border-slate-800/80 font-mono text-xs space-y-1.5">
            <div className="flex justify-between text-slate-400">
              <span>Harmonic Drive:</span>
              <span className="text-amber-300 font-bold">{params.goldenEarDrive.toFixed(2)}x</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Exciter Mix:</span>
              <span className="text-slate-200">{(params.goldenEarMix * 100).toFixed(0)}%</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Tanh Method:</span>
              <span className="text-emerald-400 font-bold">1-Iter Newton</span>
            </div>
          </div>
        </div>

      </div>

      {/* Deep Technical Explanations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Math & NEON Features */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-cyan-400 flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            Mathematical Perfection & ARM NEON Optimizations
          </h3>
          <ul className="space-y-2.5 text-slate-300 text-xs leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="text-cyan-400 font-bold">1.</span>
              <span>
                <strong className="text-slate-100">SIMD Fused Multiply-Add (FMA):</strong> All convolution and matrix updates utilize <code className="bg-slate-950 px-1 py-0.5 rounded border border-slate-800 text-emerald-300">vmlaq_f32</code> and <code className="bg-slate-950 px-1 py-0.5 rounded border border-slate-800 text-emerald-300">vld1q_f32</code>, processing 4 32-bit floats per instruction cycle.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-cyan-400 font-bold">2.</span>
              <span>
                <strong className="text-slate-100">Fast Tanh Approximation:</strong> Evaluates f(x) = x*(27 + x^2) / (27 + 9*x^2) using NEON reciprocal estimate <code className="bg-slate-950 px-1 py-0.5 rounded text-amber-300">vrecpeq_f32</code> followed by one Newton-Raphson iteration <code className="bg-slate-950 px-1 py-0.5 rounded text-amber-300">vrecpsq_f32</code>, avoiding costly standard library transcendental operations.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-cyan-400 font-bold">3.</span>
              <span>
                <strong className="text-slate-100">Zero Quantization Error:</strong> TinyML LSTM weights and states operate in int8/int16 domain, mapping cell sums to fixed point Q.7/Q.8 scales without floating-point underflow.
              </span>
            </li>
          </ul>
        </div>

        {/* Zero-Allocation Rules */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-400" />
            Zero-Allocation & L1 Cache Guarantees
          </h3>
          <ul className="space-y-2.5 text-slate-300 text-xs leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">1.</span>
              <span>
                <strong className="text-slate-100">Heap-Free Audio Thread:</strong> Zero <code className="text-rose-400">malloc</code>, <code className="text-rose-400">new</code>, or resizing <code className="text-rose-400">std::vector</code> inside <code className="text-emerald-300">process()</code>. All historical sample frames reside in static ring buffers.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">2.</span>
              <span>
                <strong className="text-slate-100">Strict 16-Byte Alignment:</strong> Every audio block buffer uses <code className="bg-slate-950 px-1 py-0.5 rounded text-cyan-300">alignas(16)</code> matching 128-bit NEON SIMD registers to eliminate unaligned vector load penalties.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">3.</span>
              <span>
                <strong className="text-slate-100">LM-CMA-ES Phase Lock:</strong> The evolutionary optimizer enforces penalization on adjacent genome deltas (fitness = -sum(g_i - g_i-1)^2), maintaining smooth frequency transitions and zero phase smearing in FIR filters.
              </span>
            </li>
          </ul>
        </div>

      </div>

    </div>
  );
};
