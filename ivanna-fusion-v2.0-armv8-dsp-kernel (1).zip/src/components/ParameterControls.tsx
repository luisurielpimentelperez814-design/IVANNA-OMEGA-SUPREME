import React from 'react';
import { DspParameters } from '../types';
import { Sliders, Zap, ShieldAlert, Cpu, Waves } from 'lucide-react';

interface ParameterControlsProps {
  params: DspParameters;
  onParamChange: (key: keyof DspParameters, value: number | boolean) => void;
}

export const ParameterControls: React.FC<ParameterControlsProps> = ({ params, onParamChange }) => {
  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-6 font-mono text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          Interactive DSP Hardware Parameter Fine-Tuning
        </h3>
        <span className="text-[10px] text-slate-400">Live Audio Thread Simulation Control</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Golden Ear Controls */}
        <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <div className="flex items-center justify-between">
            <span className="font-bold text-amber-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" />
              Golden Ear Drive
            </span>
            <span className="text-amber-300 font-bold">{params.goldenEarDrive.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="1.0"
            max="3.0"
            step="0.05"
            value={params.goldenEarDrive}
            onChange={(e) => onParamChange('goldenEarDrive', parseFloat(e.target.value))}
            className="w-full accent-amber-400 bg-slate-900 rounded"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>1.0x (Clean)</span>
            <span>3.0x (Saturated)</span>
          </div>

          <div className="pt-2 border-t border-slate-800/60">
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Harmonic Mix:</span>
              <span className="text-slate-100 font-bold">{(params.goldenEarMix * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="0.5"
              step="0.02"
              value={params.goldenEarMix}
              onChange={(e) => onParamChange('goldenEarMix', parseFloat(e.target.value))}
              className="w-full accent-amber-400 bg-slate-900 rounded mt-1"
            />
          </div>
        </div>

        {/* TinyML LSTM Fatigue Controls */}
        <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <div className="flex items-center justify-between">
            <span className="font-bold text-cyan-400 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5" />
              LSTM Fatigue Index
            </span>
            <span className="text-cyan-300 font-bold">{(params.fatigueIndex * 100).toFixed(0)}%</span>
          </div>
          <input
            type="range"
            min="0.0"
            max="1.0"
            step="0.05"
            value={params.fatigueIndex}
            onChange={(e) => {
              const fatigue = parseFloat(e.target.value);
              onParamChange('fatigueIndex', fatigue);
              onParamChange('iirAlpha', 1.0 - fatigue * 0.4);
            }}
            className="w-full accent-cyan-400 bg-slate-900 rounded"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>0% (Fresh)</span>
            <span>100% (Fatigued)</span>
          </div>

          <div className="pt-2 border-t border-slate-800/60 flex justify-between text-[11px]">
            <span className="text-slate-400">Dynamic IIR Alpha:</span>
            <span className="text-emerald-400 font-bold">{params.iirAlpha.toFixed(2)}</span>
          </div>
        </div>

        {/* 3D HRTF Crosstalk Controls */}
        <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <div className="flex items-center justify-between">
            <span className="font-bold text-blue-400 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5" />
              HRTF Crosstalk
            </span>
            <span className="text-blue-300 font-bold">{(params.crosstalkGain * 100).toFixed(0)}%</span>
          </div>
          <input
            type="range"
            min="0.0"
            max="0.6"
            step="0.02"
            value={params.crosstalkGain}
            onChange={(e) => onParamChange('crosstalkGain', parseFloat(e.target.value))}
            className="w-full accent-blue-400 bg-slate-900 rounded"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>0% (Stereo Isolated)</span>
            <span>60% (Full 3D Stage)</span>
          </div>

          <div className="pt-2 border-t border-slate-800/60 flex justify-between text-[11px]">
            <span className="text-slate-400">ITD Delay:</span>
            <span className="text-slate-200 font-bold">{params.hrtfDelayMs.toFixed(1)} ms</span>
          </div>
        </div>

        {/* LM-CMA-ES Evolution Rate Controls */}
        <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <div className="flex items-center justify-between">
            <span className="font-bold text-emerald-400 flex items-center gap-1.5">
              <Waves className="w-3.5 h-3.5" />
              CMA-ES Step Size
            </span>
            <span className="text-emerald-300 font-bold">{params.eqMutationRate.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0.02"
            max="0.30"
            step="0.01"
            value={params.eqMutationRate}
            onChange={(e) => onParamChange('eqMutationRate', parseFloat(e.target.value))}
            className="w-full accent-emerald-400 bg-slate-900 rounded"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>0.02 (Fine)</span>
            <span>0.30 (Aggressive)</span>
          </div>

          <div className="pt-2 border-t border-slate-800/60 flex justify-between text-[11px]">
            <span className="text-slate-400">FIR Taps / Bands:</span>
            <span className="text-emerald-400 font-bold">256 / 512</span>
          </div>
        </div>

      </div>
    </div>
  );
};
